import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import DynamicPage from './DynamicPage';
import SiteBuilder from './SiteBuilder';
import Login from './Login';
import './App.css';

// This is the Security Guard! 
// It checks if you have the secret token before letting you in.
const ProtectedRoute = ({ children }) => {
  const token = localStorage.getItem('adminToken');

  // If there's no token, kick them to the login screen!
  if (!token) {
    return <Navigate to="/admin/login" replace />;
  }

  // If they have the token, let them see the children (the Site Builder)
  return children;
};

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<DynamicPage />} />

        {/* Login Screen */}
        <Route path="/admin/login" element={<Login />} />

        {/* Protected Visual Builder! */}
        <Route
          path="/admin/builder"
          element={
            <ProtectedRoute>
              <SiteBuilder />
            </ProtectedRoute>
          }
        />

        {/* Any other public dynamic page (/about-us, /contact, etc) */}
        <Route path="/:slug" element={<DynamicPage />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;