import React from 'react';
import { motion } from 'framer-motion';
import Navbar from './Navbar'; 

export default function Hero() {
  return (
    // The main container. We set bg-white so the bottom part (under the wave) is perfectly white.
    <div className="relative w-full min-h-[704px] flex flex-col pt-20 px-6 font-['Poppins'] bg-white">
      
      {/* --- THE EXACT FIGMA BACKGROUND --- */}
      <div className="absolute inset-0 w-full h-full z-0 overflow-hidden">
        {/* We use preserveAspectRatio="xMidYMid slice" so it scales perfectly on all screen sizes */}
        <svg 
          className="w-full h-full object-cover object-top" 
          viewBox="0 0 1440 704" 
          fill="none" 
          xmlns="http://www.w3.org/2000/svg"
          preserveAspectRatio="xMidYMid slice"
        >
          {/* Light Blue Lower Curve */}
          <path fillRule="evenodd" clipRule="evenodd" d="M1289.54 446.5C1324.03 446.5 1405.79 445.053 1439 446.5V0H0V700.621C42.0688 702.804 85.7979 704 131.121 704C651.054 704 840.511 446.5 1289.54 446.5Z" fill="url(#paint0_linear_1_315)"/>
          
          {/* Dark Blue Main Top Curve */}
          <path d="M1440 0V652.537C1440 652.537 1262 519.631 1034 519.631C806 519.631 685.5 704 421.5 704C157.5 704 0 546.612 0 546.612V0H1440Z" fill="url(#paint1_linear_1_315)"/>
          
          {/* Faint Background Circles */}
          <circle opacity="0.05" cx="894" cy="634" r="262" fill="white"/>
          <circle opacity="0.02" cx="256" cy="-105" r="262" fill="white"/>
          
          {/* Exact Gradients from your Figma */}
          <defs>
            <linearGradient id="paint0_linear_1_315" x1="-666.432" y1="437.828" x2="-52.7159" y2="1589.72" gradientUnits="userSpaceOnUse">
              <stop stopColor="#52B4DA"/>
              <stop offset="1" stopColor="#1E3E85"/>
            </linearGradient>
            <linearGradient id="paint1_linear_1_315" x1="-644.712" y1="457.365" x2="-18.1383" y2="1596.48" gradientUnits="userSpaceOnUse">
              <stop stopColor="#1E3E85"/>
              <stop offset="1" stopColor="#336DA6"/>
            </linearGradient>
          </defs>
        </svg>
      </div>
      {/* --- END FIGMA BACKGROUND --- */}

      <Navbar />

      {/* The Text Content - Positioned on top of the SVG */}
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.2 }}
        className="relative z-10 text-center max-w-[1040px] mx-auto mt-20 md:mt-28"
      >
        <h2 className="text-[40px] md:text-[53px] font-bold text-white leading-[1.28] mb-6">
          RemoteRecruit’s Difference
        </h2>
        <p className="text-[16px] md:text-[20px] font-medium text-white opacity-80 leading-[1.6] max-w-[800px] mx-auto">
          RemoteRecruit is connecting the world with an easy-to-use platform that lets 
          full-time, part-time, and freelance workers showcase their talents to 
          businesses that need them. With no paywalls, no fees, and no barriers, there’s 
          nothing but you, your talents, and the next step in your career.
        </p>
      </motion.div>

    </div>
  );
}