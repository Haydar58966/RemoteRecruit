import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Login() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();

    const handleLogin = (e) => {
        e.preventDefault();
        setLoading(true);
        setError('');

        const formData = new URLSearchParams();
        formData.append('username', username);
        formData.append('password', password);

        fetch('/api/Login.aspx', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: formData.toString()
        })
            .then(res => res.json())
            .then(data => {
                setLoading(false);
                if (data.success) {
                    // Save the secret token in the browser's memory
                    localStorage.setItem('adminToken', data.token);
                    // Redirect them to the builder!
                    navigate('/admin/builder');
                } else {
                    setError(data.message || 'Login failed');
                }
            })
            .catch(() => {
                setLoading(false);
                setError('Server error connecting to login.');
            });
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-[#f3f4f6] font-sans">
            <div className="bg-white p-10 rounded-2xl shadow-xl w-full max-w-[400px] border border-gray-200">

                <div className="flex justify-center mb-6">
                    <div className="bg-[#111827] text-white p-4 rounded-full">
                        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
                    </div>
                </div>

                <h2 className="text-2xl font-bold text-center text-gray-800 mb-2">Admin Login</h2>
                <p className="text-center text-gray-500 mb-8 text-sm">Enter your credentials to access the Site Builder</p>

                {error && (
                    <div className="bg-red-50 text-red-500 p-3 rounded-lg text-sm mb-6 border border-red-200 text-center font-medium">
                        {error}
                    </div>
                )}

                <form onSubmit={handleLogin} className="space-y-5">
                    <div>
                        <label className="block text-sm font-bold text-gray-700 mb-1">Username</label>
                        <input
                            type="text"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            className="w-full p-3 border border-gray-300 rounded-lg outline-none focus:border-[#2d5bff] focus:ring-2 focus:ring-blue-100 transition"
                            required
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-bold text-gray-700 mb-1">Password</label>
                        <input
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full p-3 border border-gray-300 rounded-lg outline-none focus:border-[#2d5bff] focus:ring-2 focus:ring-blue-100 transition"
                            required
                        />
                    </div>
                    <button
                        type="submit"
                        disabled={loading}
                        className="w-full bg-[#2d5bff] text-white py-3 rounded-lg font-bold hover:bg-blue-700 transition shadow-md disabled:opacity-50 mt-4"
                    >
                        {loading ? 'Verifying...' : 'Sign In'}
                    </button>
                </form>

            </div>
        </div>
    );
}