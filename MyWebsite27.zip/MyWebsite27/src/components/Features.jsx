import React from 'react';
import { motion } from 'framer-motion';

export default function Features() {
  return (
    <div className="w-full bg-white px-6 py-20 md:py-32 font-['Poppins']">
      <div className="max-w-[1200px] mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        
        {/* Left Side: Text */}
        <motion.div 
          initial={{ opacity: 0, x: -40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          {/* Small pill-shaped badge */}
          <div className="bg-[#d2f3fd] text-[#1e3e85] font-semibold text-sm py-2 px-5 rounded-full inline-block mb-6">
            Global Reach
          </div>
          
          <h3 className="text-[36px] md:text-[45px] font-bold text-[#1f2937] leading-[1.2] mb-6">
            The First Fully Global Job Board, Anywhere, Ever
          </h3>
          
          <p className="text-lg text-gray-500 leading-relaxed max-w-[450px]">
            RemoteRecruit connects candidates with businesses anywhere in the world, allowing you to hire the best talent regardless of borders.
          </p>
        </motion.div>

        {/* Right Side: Floating Images (Placeholders for now) */}
        <motion.div 
          initial={{ opacity: 0, x: 40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative h-[400px] md:h-[500px] w-full bg-gray-50 rounded-3xl border border-gray-100 shadow-sm flex items-center justify-center"
        >
           {/* You will replace this box with your actual exported Figma images later! */}
           <p className="text-gray-400 font-medium">Export your App UI image from Figma and put it here!</p>
           
           {/* A little decorative dot like in your design */}
           <div className="absolute top-10 -left-6 w-5 h-5 bg-[#336da6] rounded-full shadow-md"></div>
        </motion.div>

      </div>
    </div>
  );
}