import { useState, useEffect } from 'react';

export default function Admin() {
    const [content, setContent] = useState({});
    const [statusMessage, setStatusMessage] = useState('');

    // 1. Fetch current content when admin panel loads
    useEffect(() => {
        fetch('/api/GetContent.aspx')
            .then(res => res.json())
            .then(data => setContent(data));
    }, []);

    // 2. Handle typing in the text boxes
    const handleChange = (key, newValue) => {
        setContent(prev => ({ ...prev, [key]: newValue }));
    };

    // 3. Send the new text to our "Save" Messenger (UpdateContent.aspx)
    const handleSave = (key) => {
        setStatusMessage('Saving...');

        // Format the data to send to C#
        const formData = new URLSearchParams();
        formData.append('key', key);
        formData.append('value', content[key]);

        fetch('/api/UpdateContent.aspx', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: formData.toString()
        })
            .then(() => {
                setStatusMessage('Saved successfully!');
                setTimeout(() => setStatusMessage(''), 3000); // clear message after 3 seconds
            })
            .catch(() => setStatusMessage('Error saving!'));
    };

    return (
        <div className="min-h-screen bg-gray-50 p-10 font-sans">
            <div className="max-w-[800px] mx-auto bg-white p-8 rounded-xl shadow-md border border-gray-200">
                <h1 className="text-3xl font-bold text-[#1e3e85] mb-2">Website Admin Panel</h1>
                <p className="text-gray-500 mb-8">Edit your landing page text here. Changes are saved to the database immediately.</p>

                {statusMessage && (
                    <div className="mb-6 p-4 bg-green-100 text-green-700 rounded-lg font-medium">
                        {statusMessage}
                    </div>
                )}

                {/* Hero Title Editor */}
                <div className="mb-8">
                    <label className="block text-sm font-bold text-gray-700 mb-2">Main Hero Title</label>
                    <input
                        type="text"
                        value={content.HeroTitle || ''}
                        onChange={(e) => handleChange('HeroTitle', e.target.value)}
                        className="w-full p-3 border border-gray-300 rounded-lg mb-2 focus:outline-none focus:border-[#60b6d1]"
                    />
                    <button
                        onClick={() => handleSave('HeroTitle')}
                        className="bg-[#1e3e85] text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition"
                    >
                        Save Title
                    </button>
                </div>

                {/* Hero Subtitle Editor */}
                <div className="mb-8 border-t pt-8">
                    <label className="block text-sm font-bold text-gray-700 mb-2">Main Hero Subtitle</label>
                    <textarea
                        rows="4"
                        value={content.HeroSubtitle || ''}
                        onChange={(e) => handleChange('HeroSubtitle', e.target.value)}
                        className="w-full p-3 border border-gray-300 rounded-lg mb-2 focus:outline-none focus:border-[#60b6d1]"
                    />
                    <button
                        onClick={() => handleSave('HeroSubtitle')}
                        className="bg-[#1e3e85] text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition"
                    >
                        Save Subtitle
                    </button>
                </div>

                <div className="mt-10 text-sm text-gray-400">
                    <a href="/" className="text-[#60b6d1] underline">← Back to Live Website</a>
                </div>
            </div>
        </div>
    );
}