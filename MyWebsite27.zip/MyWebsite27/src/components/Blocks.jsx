import { motion } from 'framer-motion';

// --- ANIMATION VARIANTS ---
const navAnim = {
    initial: { opacity: 0, y: -20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.5, ease: "easeOut" }
};

const fadeUpAnim = {
    initial: { opacity: 0, y: 30 },
    whileInView: { opacity: 1, y: 0 },
    viewport: { once: true, amount: 0.2 },
    transition: { duration: 0.6, ease: "easeOut" }
};

const fadeScaleAnim = {
    initial: { opacity: 0, scale: 0.95 },
    whileInView: { opacity: 1, scale: 1 },
    viewport: { once: true, amount: 0.2 },
    transition: { duration: 0.6, ease: "easeOut" }
};

// ---  BLOCKS ---
export const NavbarBlock = ({ brandName, btnText }) => (
    <motion.div {...navAnim} className="w-full bg-[#2a3f6d] px-8 py-5 flex justify-between items-center text-white">
        <h1 className="text-xl font-bold tracking-wide">{brandName}</h1>
        <div className="flex gap-8 items-center text-sm font-medium">
            <span className="cursor-pointer hover:text-gray-200 transition-colors">Home</span>
            <span className="cursor-pointer hover:text-gray-200 transition-colors">About Us</span>
            <button aria-label={btnText} className="bg-[#ef3f42] px-6 py-2.5 rounded font-bold shadow-sm hover:scale-105 active:scale-95 transition-transform">{btnText}</button>
        </div>
    </motion.div>
);

export const HeroBlock = ({ brandName, btnText }) => (
    <motion.div {...navAnim} className="w-full bg-white border-b px-8 py-5 flex justify-between items-center text-black">
        <h1 className="text-xl font-bold tracking-wide">{brandName}</h1>
        <div className="flex gap-8 items-center text-sm font-medium text-gray-600">
            <span className="cursor-pointer hover:text-black transition-colors">Home</span>
            <span className="cursor-pointer hover:text-black transition-colors">Properties</span>
            <button aria-label={btnText} className="bg-[#2d5bff] text-white px-6 py-2.5 rounded font-bold shadow-sm hover:scale-105 active:scale-95 transition-transform">{btnText}</button>
        </div>
    </motion.div>
);

export const DropdownNavBlock = ({ brandName, link1, link2 }) => (
    <motion.div {...navAnim} className="w-full bg-gray-900 px-8 py-5 flex justify-between items-center text-white">
        <h1 className="text-xl font-bold">{brandName}</h1>
        <div className="flex gap-6 text-sm">
            <span className="cursor-pointer hover:text-gray-300 transition-colors">{link1} ▾</span>
            <span className="cursor-pointer hover:text-gray-300 transition-colors">{link2} ▾</span>
        </div>
    </motion.div>
);

export const PremiumMenuBlock = ({ brandName, subtitle }) => (
    <motion.div {...navAnim} className="w-full bg-white border-b py-6 flex flex-col items-center text-center">
        <h1 className="text-3xl font-bold text-gray-800 uppercase tracking-widest">{brandName}</h1>
        <p className="text-xs text-gray-500 tracking-[0.2em] mt-1">{subtitle}</p>
        <div className="flex gap-8 mt-6 text-sm font-semibold text-gray-600">
            <span className="cursor-pointer hover:text-black transition-colors">Home</span>
            <span className="cursor-pointer hover:text-black transition-colors">Collections</span>
            <span className="cursor-pointer hover:text-black transition-colors">Contact</span>
        </div>
    </motion.div>
);

export const TopBarBlock = ({ message, phone }) => (
    <motion.div {...navAnim} className="w-full bg-gray-100 border-b text-gray-600 text-xs py-2 px-8 flex justify-between items-center font-medium">
        <span>{message}</span>
        <span>📞 {phone}</span>
    </motion.div>
);

export const FeaturesGridBlock = ({ title, feature1, feature2, feature3 }) => (
    <motion.div {...fadeUpAnim} className="w-full py-16 px-8 bg-gray-50 text-center">
        <h2 className="text-3xl font-bold text-gray-800 mb-10">{title}</h2>
        <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 hover:-translate-y-2 hover:shadow-lg transition-all duration-300">
                <div className="text-blue-500 text-4xl mb-4">🚀</div>
                <h3 className="font-bold text-lg mb-2">{feature1}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">Top tier performance to keep your users engaged.</p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 hover:-translate-y-2 hover:shadow-lg transition-all duration-300">
                <div className="text-blue-500 text-4xl mb-4">🛡️</div>
                <h3 className="font-bold text-lg mb-2">{feature2}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">Enterprise-grade security protecting your data.</p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 hover:-translate-y-2 hover:shadow-lg transition-all duration-300">
                <div className="text-blue-500 text-4xl mb-4">⚡</div>
                <h3 className="font-bold text-lg mb-2">{feature3}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">We guarantee 99.9% uptime for your business.</p>
            </div>
        </div>
    </motion.div>
);

export const HeroSearchBlock = ({ headline, subhead, btnText }) => (
    <motion.div {...fadeScaleAnim} className="w-full bg-[#2a3f6d] py-24 px-8 text-center text-white">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">{headline}</h1>
        <p className="text-lg text-blue-200 mb-8 max-w-2xl mx-auto">{subhead}</p>
        <div className="max-w-3xl mx-auto flex gap-2">
            <input aria-label="Search" type="text" placeholder="Search..." className="flex-1 p-4 rounded-lg text-black outline-none shadow-inner focus:ring-2 focus:ring-[#ef3f42] transition-all" />
            <button aria-label={btnText} className="bg-[#ef3f42] px-8 py-4 rounded-lg font-bold hover:bg-red-600 hover:scale-105 active:scale-95 transition-all shadow-lg">{btnText}</button>
        </div>
    </motion.div>
);

export const GlassSearchBlock = ({ headline, subhead, btnText }) => (
    <motion.div {...fadeScaleAnim} className="w-full py-24 px-8 text-center bg-gradient-to-br from-blue-400 to-indigo-600">
        <div className="max-w-3xl mx-auto bg-white/20 backdrop-blur-md border border-white/30 p-10 rounded-2xl shadow-2xl">
            <h1 className="text-4xl font-bold mb-2 text-white">{headline}</h1>
            <p className="text-blue-50 mb-8">{subhead}</p>
            <div className="flex gap-2">
                <input aria-label="Search what you are looking for" type="text" placeholder="What are you looking for?" className="flex-1 p-4 rounded-lg outline-none bg-white/90 focus:ring-2 focus:ring-[#111827] transition-all" />
                <button aria-label={btnText} className="bg-[#111827] text-white px-8 py-4 rounded-lg font-bold hover:bg-gray-800 hover:scale-105 active:scale-95 transition-all">{btnText}</button>
            </div>
        </div>
    </motion.div>
);

export const FooterBlock = ({ brandName, description, email }) => (
    <motion.div {...fadeUpAnim} className="w-full bg-[#111827] text-white py-12 px-8">
        <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
                <h2 className="text-2xl font-bold mb-4">{brandName}</h2>
                <p className="text-gray-400 text-sm leading-relaxed">{description}</p>
            </div>
            <div>
                <h3 className="font-bold mb-4 text-gray-300">Quick Links</h3>
                <ul className="text-gray-400 text-sm space-y-2">
                    <li className="hover:text-white hover:translate-x-1 cursor-pointer transition-all">Home</li>
                    <li className="hover:text-white hover:translate-x-1 cursor-pointer transition-all">About Us</li>
                    <li className="hover:text-white hover:translate-x-1 cursor-pointer transition-all">Contact</li>
                </ul>
            </div>
            <div>
                <h3 className="font-bold mb-4 text-gray-300">Contact Us</h3>
                <p className="text-gray-400 text-sm hover:text-white transition-colors cursor-pointer">Email: {email}</p>
            </div>
        </div>
    </motion.div>
);

export const SimpleFooterBlock = ({ text }) => (
    <motion.div {...fadeUpAnim} className="w-full bg-white border-t border-gray-200 py-6 text-center text-gray-500 text-sm font-medium">
        {text}
    </motion.div>
);


// --- 🚀 NEW REMOTE RECRUIT BLOCKS 🚀 ---

export const RemoteNavBlock = ({ brandName, signInText, signUpText, logoUrl }) => {
    const cleanBrandName = (brandName || 'RemoteRecruit').replace(/\s+/g, '');
    const isRemoteRecruit = cleanBrandName.toLowerCase() === 'remoterecruit';
    const brandTop = isRemoteRecruit ? 'Remote' : brandName;
    const brandBottom = isRemoteRecruit ? 'Recruit' : '';

    return (
        <motion.div {...navAnim} className="relative z-20 h-0 w-full overflow-visible font-['Poppins']">
            <nav className="absolute left-0 top-0 z-20 flex w-full items-start justify-between px-6 pt-7 text-white md:px-[52px] md:pt-[31px]">
                <div className="flex min-h-[58px] cursor-pointer items-start hover:scale-105 transition-transform">
                    {logoUrl ? (
                        <img
                            src={logoUrl}
                            alt={`${cleanBrandName} logo`}
                            loading="lazy"
                            className="h-auto w-[126px] max-w-full object-contain md:w-[132px]"
                        />
                    ) : (
                        <div className="relative flex flex-col items-start text-[29px] font-extrabold leading-[0.82] tracking-normal">
                            <span className="text-[#60b6d1]">{brandTop}</span>
                            {brandBottom ? (
                                <span className="relative text-white before:absolute before:left-[-9px] before:top-[15px] before:h-[6px] before:w-[6px] before:rounded-full before:bg-[#60b6d1]">
                                    {brandBottom}
                                </span>
                            ) : null}
                        </div>
                    )}
                </div>

                <div className="flex items-center gap-5 text-sm font-bold md:gap-[34px] md:text-[17px]">
                    <span className="cursor-pointer transition-colors hover:text-white/80">{signInText}</span>
                    <button aria-label={signUpText} className="min-w-[95px] rounded-[22px] bg-[#60b6d1] px-[22px] py-3 text-center font-bold text-white shadow-[0_16px_30px_rgba(36,112,155,0.18)] hover:scale-105 active:scale-95 transition-all hover:bg-[#52a8c3]">
                        {signUpText}
                    </button>
                </div>
            </nav>
        </motion.div>
    );
};

export const RemoteHeroBlock = ({ title, subtitle }) => (
    <motion.div {...fadeScaleAnim} className="relative flex min-h-[704px] w-full flex-col overflow-hidden bg-white px-6 pt-20 font-['Poppins']">
        <div className="absolute inset-0 z-0 h-full w-full overflow-hidden">
            <svg
                className="h-full w-full object-cover object-top"
                viewBox="0 0 1440 704"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                preserveAspectRatio="xMidYMid slice"
            >
                <path fillRule="evenodd" clipRule="evenodd" d="M1289.54 446.5C1324.03 446.5 1405.79 445.053 1439 446.5V0H0V700.621C42.0688 702.804 85.7979 704 131.121 704C651.054 704 840.511 446.5 1289.54 446.5Z" fill="url(#remoteHeroLowerCurve)" />
                <path d="M1440 0V652.537C1440 652.537 1262 519.631 1034 519.631C806 519.631 685.5 704 421.5 704C157.5 704 0 546.612 0 546.612V0H1440Z" fill="url(#remoteHeroMainCurve)" />
                <circle opacity="0.05" cx="894" cy="634" r="262" fill="white" />
                <circle opacity="0.02" cx="256" cy="-105" r="262" fill="white" />
                <defs>
                    <linearGradient id="remoteHeroLowerCurve" x1="-666.432" y1="437.828" x2="-52.7159" y2="1589.72" gradientUnits="userSpaceOnUse">
                        <stop stopColor="#52B4DA" />
                        <stop offset="1" stopColor="#1E3E85" />
                    </linearGradient>
                    <linearGradient id="remoteHeroMainCurve" x1="-644.712" y1="457.365" x2="-18.1383" y2="1596.48" gradientUnits="userSpaceOnUse">
                        <stop stopColor="#1E3E85" />
                        <stop offset="1" stopColor="#336DA6" />
                    </linearGradient>
                </defs>
            </svg>
        </div>

        <div className="relative z-10 mx-auto mt-20 max-w-[1040px] text-center text-white md:mt-28">
            <h2 className="mb-6 text-[40px] font-bold leading-[1.28] text-white md:text-[53px]">
                {title}
            </h2>
            <p className="mx-auto max-w-[800px] text-[16px] font-medium leading-[1.6] text-white opacity-80 md:text-[20px]">
                {subtitle}
            </p>
        </div>
    </motion.div>
);

export const RemoteFeatureBlock = ({ badgeText, title, description, imageUrl }) => (
    <motion.div {...fadeUpAnim} className="w-full bg-white py-20 px-10">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center gap-16">

            {/* Left Text */}
            <div className="flex-1 text-left">
                <span className="inline-block bg-[#d2f3fd] text-[#336da6] px-5 py-2 rounded-full text-sm font-bold mb-6">
                    {badgeText}
                </span>
                <h2 className="text-4xl md:text-5xl font-bold text-[#111827] mb-6 leading-tight">
                    {title}
                </h2>
                <p className="text-gray-500 text-lg leading-relaxed">
                    {description}
                </p>
            </div>

            {/* Right Image */}
            <div className="flex-1 flex justify-center relative w-full">
                {imageUrl ? (
                    <img loading="lazy" src={imageUrl} alt={`Feature showing ${title}`} className="max-w-full h-auto drop-shadow-2xl rounded-2xl hover:scale-[1.02] transition-transform duration-300" />
                ) : (
                    <div className="w-full aspect-square bg-gray-50 rounded-2xl flex flex-col items-center justify-center border-2 border-dashed border-gray-300 text-gray-400 p-8 text-center">
                        <span className="text-4xl mb-2">🖼️</span>
                        <p className="font-bold">Image Placeholder</p>
                        <p className="text-xs mt-2">Open your File Explorer, upload an image, and paste the URL into the Settings panel!</p>
                    </div>
                )}
            </div>

        </div>
    </motion.div>
);

export const RemoteFeatureReverseBlock = ({ badgeText, title, description, imageUrl }) => (
    <motion.div {...fadeUpAnim} className="w-full bg-white py-20 px-10">
        <div className="max-w-6xl mx-auto flex flex-col-reverse md:flex-row items-center gap-16">

            {/* Left Image */}
            <div className="flex-1 flex justify-center relative w-full">
                {imageUrl ? (
                    <img loading="lazy" src={imageUrl} alt={`Feature showing ${title}`} className="max-w-full h-auto drop-shadow-2xl rounded-2xl hover:scale-[1.02] transition-transform duration-300" />
                ) : (
                    <div className="w-full aspect-square bg-gray-50 rounded-2xl flex flex-col items-center justify-center border-2 border-dashed border-gray-300 text-gray-400 p-8 text-center">
                        <span className="text-4xl mb-2">🖼️</span>
                        <p className="font-bold">Image Placeholder</p>
                        <p className="text-xs mt-2">Open your File Explorer, upload an image, and paste the URL into the Settings panel!</p>
                    </div>
                )}
            </div>

            {/* Right Text */}
            <div className="flex-1 text-left">
                <span className="inline-block bg-[#d2f3fd] text-[#336da6] px-5 py-2 rounded-full text-sm font-bold mb-6">
                    {badgeText}
                </span>
                <h2 className="text-4xl md:text-5xl font-bold text-[#111827] mb-6 leading-tight">
                    {title}
                </h2>
                <p className="text-gray-500 text-lg leading-relaxed">
                    {description}
                </p>
            </div>

        </div>
    </motion.div>
);

export const RemoteCtaBlock = ({ subtitle, title, description, btnText, imageUrl }) => (
    <motion.div {...fadeScaleAnim} className="relative w-full bg-gradient-to-r from-[#edf2fa] to-[#edeaf6] py-24 px-8 overflow-hidden">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center gap-12">

            {/* Left Image (Mockup) */}
            <div className="flex-1 w-full flex justify-start relative z-10">
                {imageUrl ? (
                    <img loading="lazy" src={imageUrl} alt="Dashboard UI preview" className="w-[120%] max-w-none -ml-8 md:-ml-20 drop-shadow-2xl rounded-l-none rounded-r-2xl hover:scale-[1.02] transition-transform duration-300" />
                ) : (
                    <div className="w-full aspect-video bg-white/60 rounded-r-2xl flex flex-col items-center justify-center border-2 border-dashed border-blue-300 text-blue-500 p-8 text-center backdrop-blur-sm -ml-8 md:-ml-20">
                        <span className="text-4xl mb-2">💻</span>
                        <p className="font-bold">Dashboard Image</p>
                    </div>
                )}
            </div>

            {/* Right Text */}
            <div className="flex-1 text-left z-10 md:pl-8">
                <p className="text-[#336da6] font-bold mb-3">{subtitle}</p>
                <h2 className="text-4xl md:text-5xl font-bold text-[#111827] mb-6 leading-tight">{title}</h2>
                <p className="text-gray-500 text-lg mb-8 max-w-md">{description}</p>
                <button aria-label={btnText} className="bg-[#d2f3fd] text-[#204987] pr-6 pl-2 py-2 rounded-full font-bold hover:bg-[#b0e8fa] hover:scale-105 active:scale-95 transition-all flex items-center gap-3">
                    <span className="bg-[#60b6d1] text-white rounded-full w-10 h-10 flex items-center justify-center text-xl">→</span>
                    {btnText}
                </button>
            </div>
        </div>

        {/* Decorative blur circles */}
        <div className="absolute top-10 left-40 w-20 h-20 bg-yellow-400 rounded-full blur-md opacity-80"></div>
        <div className="absolute bottom-16 right-1/4 w-10 h-10 bg-blue-600 rounded-full blur-[2px] opacity-80"></div>
    </motion.div>
);

export const RemoteFaqBlock = ({ mainTitle, q1, a1, q2, a2, q3, a3, btnText }) => {
    const itemAnim = {
        initial: { opacity: 0, y: 20 },
        whileInView: { opacity: 1, y: 0 },
        viewport: { once: true, amount: 0.3 },
        transition: { duration: 0.5, ease: "easeOut" }
    };

    return (
        <motion.div {...fadeUpAnim} className="w-full bg-white py-24 px-10">
            <div className="max-w-4xl mx-auto">
                <h2 className="text-4xl font-bold text-[#111827] mb-12 text-center md:text-left">{mainTitle}</h2>

                <div className="space-y-6">
                    <motion.div 
                        {...itemAnim}
                        className="p-8 rounded-2xl bg-gray-50 border border-gray-100 hover:bg-white hover:shadow-[0_8px_30px_rgba(0,0,0,0.06)] hover:border-blue-100 transition-all duration-300"
                        whileHover={{ scale: 1.01, y: -4 }}
                    >
                        <h3 className="text-xl font-bold text-[#111827] mb-4 flex items-center gap-4">
                            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#d2f3fd] text-[#336da6] text-base font-extrabold shadow-sm">Q</span>
                            {q1}
                        </h3>
                        <p className="text-gray-500 leading-relaxed pl-14">{a1}</p>
                    </motion.div>
                    <motion.div 
                        {...itemAnim}
                        transition={{ ...itemAnim.transition, delay: 0.1 }}
                        className="p-8 rounded-2xl bg-gray-50 border border-gray-100 hover:bg-white hover:shadow-[0_8px_30px_rgba(0,0,0,0.06)] hover:border-blue-100 transition-all duration-300"
                        whileHover={{ scale: 1.01, y: -4 }}
                    >
                        <h3 className="text-xl font-bold text-[#111827] mb-4 flex items-center gap-4">
                            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#d2f3fd] text-[#336da6] text-base font-extrabold shadow-sm">Q</span>
                            {q2}
                        </h3>
                        <p className="text-gray-500 leading-relaxed pl-14">{a2}</p>
                    </motion.div>
                    <motion.div 
                        {...itemAnim}
                        transition={{ ...itemAnim.transition, delay: 0.2 }}
                        className="p-8 rounded-2xl bg-gray-50 border border-gray-100 hover:bg-white hover:shadow-[0_8px_30px_rgba(0,0,0,0.06)] hover:border-blue-100 transition-all duration-300"
                        whileHover={{ scale: 1.01, y: -4 }}
                    >
                        <h3 className="text-xl font-bold text-[#111827] mb-4 flex items-center gap-4">
                            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#d2f3fd] text-[#336da6] text-base font-extrabold shadow-sm">Q</span>
                            {q3}
                        </h3>
                        <p className="text-gray-500 leading-relaxed pl-14">{a3}</p>
                    </motion.div>
                </div>

                <div className="mt-12 flex justify-center md:justify-start">
                    <button aria-label={btnText} className="border-2 border-[#336da6] text-[#336da6] px-8 py-3 rounded-xl font-bold hover:bg-[#f0f8fb] hover:scale-105 active:scale-95 transition-all">
                        {btnText}
                    </button>
                </div>
            </div>
        </motion.div>
    );
};

const PricingFeatureIcon = ({ unavailable = false }) => (
    <span
        className={`inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-white shadow-sm ${unavailable
            ? 'bg-[linear-gradient(135deg,#aeb3c3,#7f8597)]'
            : 'bg-[linear-gradient(135deg,#63c4de,#2a6199)]'
            }`}
    >
        {unavailable ? (
            <svg className="h-2.5 w-2.5" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                <path d="M4.25 4.25L11.75 11.75M11.75 4.25L4.25 11.75" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" />
            </svg>
        ) : (
            <svg className="h-3 w-3" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                <path d="M3.2 8.15L6.45 11.35L12.85 4.85" stroke="currentColor" strokeWidth="2.7" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
        )}
    </span>
);

const PricingFeatureRow = ({ children, unavailable = false }) => (
    <div className="flex items-start gap-2.5">
        <PricingFeatureIcon unavailable={unavailable} />
        <span
            className={`pt-0.5 text-left text-sm font-bold leading-snug md:text-base ${unavailable ? 'text-[#8b91a3]' : 'text-[#363648]'
                }`}
        >
            {children}
        </span>
    </div>
);

const PremiumLeafIcon = () => (
    <span className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-white shadow-sm">
        <svg className="h-4 w-3" viewBox="0 0 31 42" fill="none" aria-hidden="true">
            <path d="M14.48 2.02C22.4 11.25 25.6 18.75 23.98 24.5C22.58 29.45 18.6 33.56 12.03 36.84C10.92 30.34 9.8 24.16 8.67 18.31C7.86 14.11 9.8 8.68 14.48 2.02Z" fill="#0b3653" />
            <path d="M16.74 4.75C19.92 13.17 20.27 20.12 17.78 25.61C15.78 30.01 12.38 33.78 7.58 36.91C5.85 31.25 5 25.66 5.04 20.14C5.08 15.26 8.98 10.13 16.74 4.75Z" fill="#65c6df" opacity="0.9" />
            <path d="M14.34 10.65C13.42 17.11 11.64 24.88 9 33.95" stroke="white" strokeWidth="1.45" strokeLinecap="round" opacity="0.7" />
            <path d="M14.06 14.9L19.06 19.48M12.74 20.47L17.11 24.28M11.38 25.94L14.65 28.68" stroke="white" strokeWidth="1.25" strokeLinecap="round" opacity="0.55" />
        </svg>
    </span>
);

export const RemotePricingBlock = ({ title, freeTitle, freeSubtitle, premiumPrice, premiumSubtitle, btnText }) => (
    <motion.section {...fadeUpAnim} className="relative isolate w-full overflow-hidden bg-white px-4 py-16 md:py-20 text-center font-['Poppins']">
        <div className="pointer-events-none absolute inset-x-0 bottom-0 z-0 h-[140px] bg-[linear-gradient(130deg,#3476aa_0%,#255b99_45%,#244f91_100%)]">
            <svg
                className="absolute left-0 top-[-80px] h-[120px] w-full"
                viewBox="0 0 2048 430"
                preserveAspectRatio="none"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
            >
                <path
                    d="M0 189C233 177 408 185 563 221C704 254 797 312 946 330C1113 350 1237 270 1402 279C1587 289 1771 381 2048 353V430H0V189Z"
                    fill="url(#remotePricingWave)"
                />
                <path
                    d="M0 189C233 177 408 185 563 221C704 254 797 312 946 330C1113 350 1237 270 1402 279C1587 289 1771 381 2048 353"
                    stroke="#55bed7"
                    strokeWidth="7"
                />
                <defs>
                    <linearGradient id="remotePricingWave" x1="2" y1="191" x2="2048" y2="418" gradientUnits="userSpaceOnUse">
                        <stop stopColor="#3474aa" />
                        <stop offset="0.48" stopColor="#265999" />
                        <stop offset="1" stopColor="#254f91" />
                    </linearGradient>
                </defs>
            </svg>
        </div>

        <h2 className="relative z-10 mb-10 text-3xl md:text-4xl font-extrabold text-[#101329]">
            {title}
        </h2>

        <div className="relative z-10 mx-auto flex max-w-4xl flex-col items-stretch justify-center gap-6 md:flex-row">
            <div className="flex flex-1 flex-col justify-between rounded-2xl bg-white p-6 shadow-[0_8px_30px_rgba(31,69,113,0.08)] md:min-h-[320px] hover:-translate-y-2 transition-transform duration-300">
                <div className="mb-6 flex flex-col gap-5 md:flex-row md:items-center">
                    <div className="flex min-h-[140px] w-full shrink-0 items-center justify-center rounded-xl bg-[#edf3ff] p-5 md:w-[150px]">
                        <div className="flex flex-col items-center leading-none">
                            <span className="text-2xl font-extrabold text-[#61bed7]">{freeTitle}</span>
                            <span className="mt-2 text-lg font-bold text-[#9599aa]">{freeSubtitle}</span>
                        </div>
                    </div>

                    <div className="flex flex-1 flex-col justify-center gap-3">
                        <PricingFeatureRow>1 Active Job</PricingFeatureRow>
                        <PricingFeatureRow>Basic List Placement</PricingFeatureRow>
                        <PricingFeatureRow unavailable>Unlimited Job Applicants</PricingFeatureRow>
                        <PricingFeatureRow unavailable>Invite Anyone to Apply to Your Jobs</PricingFeatureRow>
                    </div>
                </div>

                <button aria-label={`${btnText} for ${freeTitle} plan`} className="flex h-12 w-full items-center justify-center rounded-xl border-[2px] border-[#2f6ca3] bg-white text-base font-extrabold text-[#254e92] transition-all hover:bg-[#f2f8ff] hover:scale-[1.02] active:scale-95">
                    {btnText}
                </button>
            </div>

            <div className="flex flex-1 flex-col justify-between rounded-2xl bg-white p-6 shadow-[0_8px_30px_rgba(31,69,113,0.08)] md:min-h-[320px] hover:-translate-y-2 transition-transform duration-300">
                <div className="mb-6 flex flex-col gap-5 md:flex-row md:items-center">
                    <div className="relative flex min-h-[140px] w-full shrink-0 items-center justify-center rounded-xl bg-[#edf3ff] p-5 md:w-[150px]">
                        <div className="absolute -top-3 left-1/2 flex -translate-x-1/2 items-center gap-1.5 rounded-full bg-[#c6f2ff] px-3 py-1 text-[#101329] shadow-sm md:left-3 md:-translate-x-0">
                            <PremiumLeafIcon />
                            <span className="text-sm font-extrabold">Premium</span>
                        </div>

                        <div className="flex flex-col items-center leading-none">
                            <span className="text-2xl font-extrabold text-[#3d92c5]">{premiumPrice}</span>
                            <span className="mt-2 text-lg font-bold text-[#9599aa]">{premiumSubtitle}</span>
                        </div>
                    </div>

                    <div className="flex flex-1 flex-col justify-center gap-3">
                        <PricingFeatureRow>Unlimited Job Posts</PricingFeatureRow>
                        <PricingFeatureRow>Instant Job Post Approval</PricingFeatureRow>
                        <PricingFeatureRow>Premium List Placement</PricingFeatureRow>
                        <PricingFeatureRow>Unlimited Job Applicants</PricingFeatureRow>
                    </div>
                </div>

                <button aria-label={`${btnText} for Premium plan`} className="flex h-12 w-full items-center justify-center rounded-xl bg-[linear-gradient(90deg,#3374aa_0%,#234b8f_100%)] text-base font-extrabold text-white transition-all hover:brightness-110 hover:scale-[1.02] active:scale-95 shadow-md">
                    {btnText}
                </button>
            </div>
        </div>
    </motion.section>
);

const RemoteFooterWordmark = ({ brandWord1, brandWord2 }) => (
    <div className="relative inline-flex flex-col items-start text-3xl font-extrabold leading-none tracking-normal md:text-4xl">
        <span className="relative text-[#62c1dc]">
            <span className="absolute left-0 top-1.5 h-1 w-4 rounded-full bg-white" aria-hidden="true"></span>
            <span className="relative">{brandWord1}</span>
        </span>
        <span className="relative pl-5 text-white">
            <span className="absolute left-0 top-5 h-1.5 w-1.5 rounded-full bg-[#62c1dc]" aria-hidden="true"></span>
            {brandWord2}
        </span>
    </div>
);

const RemoteFooterMiniMark = () => (
    <span className="relative inline-flex h-8 w-10 items-center justify-center" aria-hidden="true">
        <svg className="h-6 w-8" viewBox="0 0 90 70" fill="none">
            <path d="M20 12H43C54.5 12 62.5 18.8 62.5 29.1C62.5 37.2 57.3 43.6 49.4 46.1L66 64H50.4L35.2 47.4H31.5V64H20V12ZM31.5 22.6V37.1H42C47.5 37.1 50.8 34.2 50.8 29.8C50.8 25.3 47.5 22.6 42 22.6H31.5Z" fill="white" />
            <path d="M43.5 12H66.5C78 12 86 18.8 86 29.1C86 37.2 80.8 43.6 72.9 46.1L89.5 64H73.9L58.7 47.4H55V64H43.5V12ZM55 22.6V37.1H65.5C71 37.1 74.3 34.2 74.3 29.8C74.3 25.3 71 22.6 65.5 22.6H55Z" fill="#62c1dc" />
        </svg>
    </span>
);

export const RemoteFooterBlock = ({
    brandWord1,
    brandWord2,
    logoUrl,
    bottomLogoUrl,
    facebookIconUrl,
    instagramIconUrl,
    xIconUrl,
    twitterIconUrl,
    linkedinIconUrl,
    snapchatIconUrl
}) => {
    const mainLogoAlt = `${brandWord1 || 'Remote'} ${brandWord2 || 'Recruit'} logo`;

    const socialIcons = [
        {
            label: 'Facebook',
            iconUrl: facebookIconUrl,
            fallback: <span className="text-[16px] font-extrabold leading-none">f</span>
        },
        {
            label: 'Instagram',
            iconUrl: instagramIconUrl,
            fallback: (
                <svg className="h-[14px] w-[14px]" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                    <rect x="4" y="4" width="16" height="16" rx="5" stroke="currentColor" strokeWidth="2" />
                    <circle cx="12" cy="12" r="3.5" stroke="currentColor" strokeWidth="2" />
                    <circle cx="17" cy="7" r="1.2" fill="currentColor" />
                </svg>
            )
        },
        {
            label: 'X',
            iconUrl: xIconUrl,
            fallback: <span className="text-[12px] font-medium leading-none">X</span>
        },
        {
            label: 'Twitter',
            iconUrl: twitterIconUrl,
            fallback: (
                <svg className="h-[14px] w-[14px]" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M20.5 6.3c-.6.3-1.2.4-1.9.5.7-.4 1.1-1 1.4-1.8-.6.4-1.3.6-2 .8A3.2 3.2 0 0 0 12.5 8c0 .2 0 .5.1.7-2.7-.1-5.1-1.4-6.7-3.4-.3.5-.4 1-.4 1.6 0 1.1.6 2.1 1.4 2.7-.5 0-1-.2-1.5-.4v.1c0 1.6 1.1 2.9 2.6 3.2-.3.1-.6.1-.9.1-.2 0-.4 0-.6-.1.4 1.3 1.6 2.2 3 2.2A6.5 6.5 0 0 1 4.7 16c-.3 0-.6 0-.9-.1 1.4.9 3.1 1.4 4.9 1.4 5.8 0 9-4.8 9-9v-.4c.6-.4 1.1-1 1.5-1.6z" />
                </svg>
            )
        },
        {
            label: 'LinkedIn',
            iconUrl: linkedinIconUrl,
            fallback: <span className="text-[10px] font-extrabold leading-none">in</span>
        },
        {
            label: 'Snapchat',
            iconUrl: snapchatIconUrl,
            fallback: (
                <svg className="h-[14px] w-[14px]" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M12 3.8c-2.4 0-4.1 1.7-4.1 4.3v2c0 .4-.4.7-.9.8-.5.2-1 .4-1 .9 0 .4.4.7 1.1 1 .8.3 1.2.7 1.5 1.4.2.6.7.8 1.4.7.5-.1.9.1 1.2.5.2.3.5.5.8.5s.6-.2.8-.5c.3-.4.7-.6 1.2-.5.7.1 1.2-.1 1.4-.7.3-.7.7-1.1 1.5-1.4.7-.3 1.1-.6 1.1-1 0-.5-.5-.7-1-.9-.5-.1-.9-.4-.9-.8v-2c0-2.6-1.7-4.3-4.1-4.3z" />
                </svg>
            )
        }
    ];

    return (
        <motion.footer {...fadeUpAnim} className="relative -mt-px w-full overflow-hidden bg-[linear-gradient(130deg,#3475aa_0%,#285d9f_44%,#244f91_100%)] px-4 pt-16 pb-0 font-['Poppins'] text-white md:px-8 md:pt-20">
            <div className="pointer-events-none absolute right-[-40px] top-[-40px] h-[200px] w-[200px] rounded-full bg-[#5f84bd]/18"></div>
            <div className="pointer-events-none absolute bottom-[-100px] left-[40px] h-[200px] w-[200px] rounded-full bg-[#5f84bd]/14"></div>

            <div className="relative z-10 mx-auto mb-12 flex max-w-4xl flex-col items-center justify-between gap-8 md:mb-16 md:flex-row md:items-center">
                <div className="flex items-center hover:scale-105 transition-transform">
                    {logoUrl ? (
                        <img
                            src={logoUrl}
                            alt={mainLogoAlt}
                            loading="lazy"
                            className="h-auto w-[160px] max-w-full object-contain md:w-[180px]"
                        />
                    ) : (
                        <RemoteFooterWordmark brandWord1={brandWord1} brandWord2={brandWord2} />
                    )}
                </div>

                <div className="flex flex-wrap items-center justify-center gap-3 md:justify-end">
                    {socialIcons.map(({ label, iconUrl, fallback }) => (
                        <div
                            key={label}
                            className="flex h-8 w-8 cursor-pointer items-center justify-center rounded-full bg-[#5a7db6]/70 text-white/85 shadow-sm transition-all hover:bg-[#6789bf] hover:scale-110 active:scale-95"
                            aria-label={label}
                            title={label}
                        >
                            {iconUrl ? (
                                <img loading="lazy" src={iconUrl} alt={`${label} icon`} className="h-4 w-4 object-contain" />
                            ) : fallback}
                        </div>
                    ))}
                </div>
            </div>

            <div className="relative z-10 border-t border-white/20 py-6 text-center">
                {bottomLogoUrl ? (
                    <img loading="lazy" src={bottomLogoUrl} alt="Bottom logo" className="mx-auto h-auto w-10 object-contain hover:scale-105 transition-transform" />
                ) : (
                    <div className="hover:scale-105 transition-transform inline-block"><RemoteFooterMiniMark /></div>
                )}
            </div>
        </motion.footer>
    );
};

// --- REGISTRY AND DEFAULTS ---
export const BlockRegistry = {
    NavbarBlock, HeroBlock, DropdownNavBlock, PremiumMenuBlock,
    TopBarBlock, FeaturesGridBlock, HeroSearchBlock, GlassSearchBlock,
    FooterBlock, SimpleFooterBlock,
    RemoteNavBlock, RemoteHeroBlock, RemoteFeatureBlock,
    RemoteFeatureReverseBlock,
    RemoteCtaBlock, RemoteFaqBlock,
    RemotePricingBlock, RemoteFooterBlock
};

export const BlockDefaults = {
    NavbarBlock: { brandName: 'MyBrand', btnText: 'Contact Us' },
    HeroBlock: { brandName: 'MyBrand', btnText: 'Contact' },
    DropdownNavBlock: { brandName: 'MyBrand', link1: 'Services', link2: 'Pricing' },
    PremiumMenuBlock: { brandName: 'LUXURY', subtitle: 'Exclusive Real Estate' },
    TopBarBlock: { message: '🎉 Special Offer: Get 20% off today!', phone: '1-800-555-0199' },
    FeaturesGridBlock: { title: 'Why Choose Us?', feature1: 'Lightning Fast', feature2: 'Highly Secure', feature3: '24/7 Support' },
    HeroSearchBlock: { headline: 'Find Your Dream Home', subhead: 'Search thousands of properties available for sale and rent.', btnText: 'Search' },
    GlassSearchBlock: { headline: 'Explore the World', subhead: 'Book your next adventure today.', btnText: 'Explore' },
    FooterBlock: { brandName: 'MyBrand', description: 'Building the future of the web, one block at a time.', email: 'hello@mybrand.com' },
    SimpleFooterBlock: { text: '© 2024 MyBrand. All rights reserved.' },

    // Defaults for new blocks
    RemoteNavBlock: { brandName: 'RemoteRecruit', signInText: 'Sign In', signUpText: 'Sign Up', logoUrl: "" },
    RemoteHeroBlock: { title: "RemoteRecruit's Difference", subtitle: "RemoteRecruit is connecting the world with an easy-to-use platform that lets full-time, part-time, and freelance workers showcase their talents to businesses that need them. With no paywalls, no fees, and no barriers, there's nothing but you, your talents, and the next step in your career." },
    RemoteFeatureBlock: { badgeText: "Global Reach", title: "The First Fully Global Job Board, Anywhere, Ever", description: "RemoteRecruit connects candidates with opportunities around the world. With today's remote-first workforce, you need to be able to find the best jobs and the best people for them, wherever they may be.", imageUrl: "" },
    RemoteFeatureReverseBlock: { badgeText: "Actually Fee Free", title: "Fee-Free Forever", description: "We don't charge you fees and we don't put up paywalls. We're the bridge that connects job opportunities with the best candidates, with no middleman involved.", imageUrl: "" },
    RemoteCtaBlock: { subtitle: "Are you ready?", title: "Help is only a few clicks away!", description: "Click Below to get set up super quickly and find help now!", btnText: "Get Started", imageUrl: "" },
    RemoteFaqBlock: { mainTitle: "Common Questions", q1: "Do I have to sign a long-term contract?", a1: "Actually beard single-origin coffee, twee 90's PBR Echo Park sartorial try-hard freegan Portland ennui.", q2: "Can I pay for a whole year?", a2: "Actually beard single-origin coffee, twee 90's PBR Echo Park sartorial try-hard freegan Portland ennui.", q3: "What if I need help?", a3: "Actually beard single-origin coffee, twee 90's PBR Echo Park sartorial try-hard freegan Portland ennui.", btnText: "More Questions" },
    RemotePricingBlock: { title: "Help Is One Click Away", freeTitle: "Free", freeSubtitle: "Basic", premiumPrice: "$79.99", premiumSubtitle: "Per Month", btnText: "Get Started" },
    RemoteFooterBlock: {
        brandWord1: "Remote",
        brandWord2: "Recruit",
        logoUrl: "",
        bottomLogoUrl: "",
        facebookIconUrl: "",
        instagramIconUrl: "",
        xIconUrl: "",
        twitterIconUrl: "",
        linkedinIconUrl: "",
        snapchatIconUrl: ""
    }
};
