import React from 'react';
import { motion } from 'framer-motion';

export default function Navbar() {
  return (
    // We use framer-motion here to make the navbar slide down and fade in gently when the page loads!
    <motion.nav 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="absolute top-0 left-0 w-full z-50 flex justify-between items-center py-6 px-6 md:px-16"
    >
      {/* Logo Section */}
      <div className="flex items-center cursor-pointer">
        {/* We are using standard text to mimic the logo for now, making "Remote" white and "Recruit" a light blue */}
        <h1 className="text-2xl font-bold text-white tracking-tight">
          Remote<span className="text-[#60b6d1]">Recruit</span>
        </h1>
      </div>

      {/* Buttons Section */}
      <div className="flex items-center gap-6">
        <a 
          href="#signin" 
          className="text-white font-medium hover:text-gray-200 transition-colors duration-200"
        >
          Sign In
        </a>
        <a 
          href="#signup" 
          className="bg-[#60b6d1] hover:bg-[#4ea2bc] text-white font-semibold py-2 px-6 rounded-full shadow-lg transition-all duration-200 transform hover:scale-105"
        >
          Sign Up
        </a>
      </div>
    </motion.nav>
  );
}