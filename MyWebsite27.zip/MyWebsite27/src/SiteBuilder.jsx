import { useState, useEffect, useRef } from 'react';
import { BlockRegistry, BlockDefaults } from './components/Blocks';
import ScrollToTop from './components/ScrollToTop';

const formatPropLabel = (propKey) =>
    propKey
        .replace(/([A-Z])/g, ' $1')
        .replace(/\bUrl\b/g, 'URL')
        .trim()
        .replace(/^./, char => char.toUpperCase());

const isImageUrlField = (propKey) => propKey.toLowerCase().endsWith('url');

const isRemoteNavLogoField = (blockType, propKey) => blockType === 'RemoteNavBlock' && propKey === 'logoUrl';

export default function SiteBuilder() {
    const [layout, setLayout] = useState([]);
    const [status, setStatus] = useState('');





    // --- PREVIEW MODE STATE ---
    const [previewMode, setPreviewMode] = useState('desktop');






    // Page Management
    const [pagesList, setPagesList] = useState(['home']);
    const [currentPage, setCurrentPage] = useState('home');
    const [newPageName, setNewPageName] = useState('');

    // Active Block for Editing
    const [activeBlockIndex, setActiveBlockIndex] = useState(null);



    // --- FILE EXPLORER STATE ---
    const [isFileExplorerOpen, setIsFileExplorerOpen] = useState(false);
    const [files, setFiles] = useState([]);
    const [uploading, setUploading] = useState(false);
    const [selectedImagePropKey, setSelectedImagePropKey] = useState(null);
    const fileInputRef = useRef(null);






    const dragItem = useRef(null);
    const dragOverItem = useRef(null);

    useEffect(() => {
        fetch('/api/GetPagesList.aspx')
            .then(res => res.json())
            .then(data => { if (Array.isArray(data) && data.length > 0) setPagesList(data); });
    }, []);

    useEffect(() => {
        setLayout([]);
        setActiveBlockIndex(null);
        fetch(`/api/GetPage.aspx?slug=${currentPage}`)
            .then(res => res.json())
            .then(data => {
                if (Array.isArray(data)) {
                    // Backward compatibility: Convert old string arrays to new object arrays
                    const formattedData = data.map(item => {
                        if (typeof item === 'string') {
                            return { id: Math.random().toString(), type: item, props: { ...BlockDefaults[item] } };
                        }
                        return {
                            ...item,
                            props: { ...BlockDefaults[item.type], ...item.props }
                        };
                    });
                    setLayout(formattedData);
                } else {
                    setLayout([]);
                }
            });
    }, [currentPage]);

    // --- PAGE MANAGER FUNCTIONS ---
    const handleCreatePage = () => {
        if (!newPageName.trim()) return;
        const slug = newPageName.trim().toLowerCase().replace(/\s+/g, '-');
        if (pagesList.includes(slug)) return alert('This page already exists!');
        setPagesList([...pagesList, slug]);
        setCurrentPage(slug);
        setNewPageName('');
    };

    const handleRenamePage = () => {
        if (currentPage === 'home') return alert("You cannot rename the home page.");
        const newName = prompt("Enter new page name (no spaces):", currentPage);
        if (!newName || newName === currentPage) return;

        const newSlug = newName.toLowerCase().replace(/\s+/g, '-');
        const formData = new URLSearchParams();
        formData.append('oldSlug', currentPage);
        formData.append('newSlug', newSlug);

        fetch('/api/RenamePage.aspx', { method: 'POST', body: formData }).then(() => {
            setPagesList(pagesList.map(p => p === currentPage ? newSlug : p));
            setCurrentPage(newSlug);
        });
    };

    const handleDeletePage = () => {
        if (currentPage === 'home') return alert("You cannot delete the home page.");
        if (!window.confirm(`Are you sure you want to delete '${currentPage}'?`)) return;

        const formData = new URLSearchParams();
        formData.append('slug', currentPage);
        fetch('/api/DeletePage.aspx', { method: 'POST', body: formData }).then(() => {
            setPagesList(pagesList.filter(p => p !== currentPage));
            setCurrentPage('home');
        });
    };

    const openLivePage = () => window.open(currentPage === 'home' ? '/' : `/${currentPage}`, '_blank');





    // --- FILE EXPLORER LOGIC ---
    useEffect(() => {
        if (isFileExplorerOpen) {
            fetch('/api/GetFiles.aspx')
                .then(res => res.json())
                .then(data => { if (Array.isArray(data)) setFiles(data); });
        }
    }, [isFileExplorerOpen]);

    const handleFileUpload = (e) => {
        const file = e.target.files[0];
        if (!file) return;

        setUploading(true);
        const formData = new FormData();
        formData.append('file', file);

        fetch('/api/UploadFile.aspx', {
            method: 'POST',
            body: formData
        })
            .then(res => res.json())
            .then(data => {
                setUploading(false);
                if (data.success) {
                    setFiles(currentFiles => [...currentFiles, data.url]);
                    applyImageToActiveField(data.url);
                }
                e.target.value = '';
            })
            .catch(() => {
                setUploading(false);
                e.target.value = '';
                alert('Upload failed!');
            });
    };

    const openImagePicker = (propKey = null) => {
        setSelectedImagePropKey(propKey);
        setIsFileExplorerOpen(true);
    };

    const uploadImageForProp = (propKey = null) => {
        setSelectedImagePropKey(propKey);
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
            fileInputRef.current.click();
        }
    };

    const applyImageToActiveField = (url) => {
        if (activeBlockIndex === null || !selectedImagePropKey) {
            navigator.clipboard.writeText(url);
            alert('Image URL copied to clipboard!');
            return;
        }

        const newLayout = [...layout];
        newLayout[activeBlockIndex].props[selectedImagePropKey] = url;
        setLayout(newLayout);
        setIsFileExplorerOpen(false);
        setSelectedImagePropKey(null);
    };




    // --- BLOCK MANAGER FUNCTIONS ---
    const addBlock = (blockName) => {
        const newBlock = { id: Math.random().toString(), type: blockName, props: { ...BlockDefaults[blockName] } };
        setLayout([...layout, newBlock]);
    };

    const removeBlock = (index) => {
        const newLayout = [...layout];
        newLayout.splice(index, 1);
        setLayout(newLayout);
        if (activeBlockIndex === index) setActiveBlockIndex(null);
    };

    const handlePropChange = (key, value) => {
        const newLayout = [...layout];
        newLayout[activeBlockIndex].props[key] = value;
        setLayout(newLayout);
    };

    const handleSort = () => {
        let _layout = [...layout];
        const draggedItemContent = _layout.splice(dragItem.current, 1)[0];
        _layout.splice(dragOverItem.current, 0, draggedItemContent);
        dragItem.current = null;
        dragOverItem.current = null;
        setLayout(_layout);
        setActiveBlockIndex(null); // Reset active block to prevent mismatched editing
    };

    const saveLayout = () => {
        setStatus('Saving...');
        const formData = new URLSearchParams();
        formData.append('slug', currentPage);
        formData.append('layout', JSON.stringify(layout));

        fetch('/api/SavePage.aspx', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: formData })
            .then(() => { setStatus('Saved!'); setTimeout(() => setStatus(''), 3000); });
    };

    return (
        <div className="flex h-screen bg-[#f3f4f6] font-sans overflow-hidden">
            <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" accept="image/*" />





            {/* --- FILE EXPLORER MODAL --- */}
            {isFileExplorerOpen && (
                <div className="absolute inset-0 bg-black/60 z-50 flex items-center justify-center p-8 backdrop-blur-sm">
                    <div className="bg-[#f8f9fa] w-full max-w-[900px] h-[80vh] rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in duration-200">
                        <div className="bg-white border-b px-6 py-4 flex justify-between items-center">
                            <h2 className="text-lg font-bold text-gray-800 flex items-center gap-2">
                                <svg className="w-5 h-5 text-blue-500" viewBox="0 0 88 88" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0 12.4L35.7 7.3V41.7H0V12.4ZM39.6 6.7L88 0V41.7H39.6V6.7ZM0 45.4H35.7V79.9L0 74.8V45.4ZM39.6 45.4H88V88L39.6 81.3V45.4Z" fill="currentColor" /></svg>
                                Media Library
                            </h2>
                            <button onClick={() => { setIsFileExplorerOpen(false); setSelectedImagePropKey(null); }} className="text-gray-400 hover:text-red-500 transition text-2xl leading-none">&times;</button>
                        </div>
                        <div className="px-6 py-4 flex justify-between items-center">
                            <p className="text-sm text-gray-500 font-medium">
                                {selectedImagePropKey ? `Click an image to use it for ${formatPropLabel(selectedImagePropKey)}.` : 'Click an image to copy its URL.'}
                            </p>
                            <button onClick={() => uploadImageForProp(selectedImagePropKey)} disabled={uploading} className="bg-[#2d5bff] text-white px-5 py-2.5 rounded-lg text-sm font-bold hover:bg-blue-700 transition shadow-sm flex items-center gap-2 disabled:opacity-50">
                                {uploading ? '⏳ Uploading...' : '☁️ Upload Image'}
                            </button>
                        </div>
                        <div className="flex-1 overflow-y-auto px-6 pb-6">
                            {files.length === 0 && !uploading ? (
                                <div className="h-full flex flex-col items-center justify-center text-gray-400">
                                    <span className="text-5xl mb-4">🖼️</span>
                                    <p>No images found. Upload your first image!</p>
                                </div>
                            ) : (
                                <div className="grid grid-cols-4 gap-4">
                                    {files.map((url, i) => (
                                        <div key={i} onClick={() => applyImageToActiveField(url)} className="group bg-white rounded-xl border border-gray-200 overflow-hidden cursor-pointer hover:border-blue-400 hover:shadow-md transition aspect-square relative flex items-center justify-center">
                                            {url.match(/\.(jpeg|jpg|gif|png|svg|webp)$/i) ? (
                                                <img src={url} alt="upload" className="object-cover w-full h-full group-hover:scale-105 transition duration-300" />
                                            ) : (<div className="text-4xl">📄</div>)}
                                            <div className="absolute inset-0 bg-blue-600/80 opacity-0 group-hover:opacity-100 transition flex items-center justify-center">
                                                <span className="text-white text-xs font-bold px-3 py-1 bg-black/50 rounded-full">{selectedImagePropKey ? 'Use Image' : 'Copy URL'}</span>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}






            {/* LEFT SIDEBAR */}
            <div className="w-[340px] bg-[#f8f9fa] border-r flex flex-col shadow-lg z-20 flex-shrink-0 [&::-webkit-scrollbar]:hidden overflow-y-auto">


                <div className="bg-[#111827] text-white p-4 flex justify-between items-center sticky top-0 z-50">




                    <div className="font-bold text-[15px]">✏️ Site Builder</div>
                    <button onClick={() => { localStorage.removeItem('adminToken'); window.location.href = '/admin/login'; }} className="text-sm text-red-400 hover:text-red-300 transition">Logout</button>
                </div>

                {/* DYNAMIC SIDEBAR: Shows "Settings" if a block is clicked, otherwise shows "Elements" */}
                {activeBlockIndex !== null ? (
                    <div className="p-4 flex-1">
                        <button onClick={() => setActiveBlockIndex(null)} className="mb-6 text-sm text-blue-600 font-bold hover:underline flex items-center gap-1">
                            ← Back to Elements
                        </button>
                        <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-200">
                            <p className="text-[11px] font-bold text-gray-400 mb-4 tracking-widest uppercase">Edit Block Settings</p>

                            {/* Automatically create an input for every property in the block */}
                            {Object.keys(layout[activeBlockIndex].props).map(propKey => {
                                const propValue = layout[activeBlockIndex].props[propKey] ?? '';
                                const imageField = isImageUrlField(propKey);
                                const logoUploadField = isRemoteNavLogoField(layout[activeBlockIndex].type, propKey);

                                if (logoUploadField) {
                                    return (
                                        <div key={propKey} className="mb-5 rounded-xl border border-blue-100 bg-blue-50 p-4">
                                            <div className="mb-3 flex items-start justify-between gap-3">
                                                <div>
                                                    <p className="text-sm font-bold text-blue-900">Logo Upload</p>
                                                    <p className="text-[11px] font-medium text-blue-500">RemoteNavBlock top-left logo</p>
                                                </div>
                                                {propValue && (
                                                    <button
                                                        type="button"
                                                        onClick={() => handlePropChange(propKey, '')}
                                                        className="text-[11px] font-bold text-red-500 hover:text-red-600"
                                                    >
                                                        Clear
                                                    </button>
                                                )}
                                            </div>

                                            <div className="mb-3 flex h-24 items-center justify-center overflow-hidden rounded-lg border border-blue-100 bg-white">
                                                {propValue ? (
                                                    <img src={propValue} alt="Remote nav logo preview" className="max-h-[72px] max-w-[180px] object-contain" />
                                                ) : (
                                                    <span className="text-xs font-semibold text-blue-300">No logo selected</span>
                                                )}
                                            </div>

                                            <div className="mb-3 grid grid-cols-2 gap-2">
                                                <button
                                                    type="button"
                                                    onClick={() => uploadImageForProp(propKey)}
                                                    disabled={uploading}
                                                    className="rounded-lg bg-[#2d5bff] px-3 py-2 text-xs font-bold text-white transition hover:bg-blue-700 disabled:opacity-50"
                                                >
                                                    {uploading && selectedImagePropKey === propKey ? 'Uploading...' : 'Upload Logo'}
                                                </button>
                                                <button
                                                    type="button"
                                                    onClick={() => openImagePicker(propKey)}
                                                    className="rounded-lg border border-blue-200 bg-white px-3 py-2 text-xs font-bold text-blue-700 transition hover:bg-blue-100"
                                                >
                                                    Choose from Media
                                                </button>
                                            </div>

                                            <label className="block text-xs font-bold text-gray-700 mb-1">Logo URL</label>
                                            <input
                                                type="text"
                                                value={propValue}
                                                placeholder="Paste logo image URL"
                                                onChange={(e) => handlePropChange(propKey, e.target.value)}
                                                className="w-full p-2.5 border border-blue-100 rounded-lg text-sm bg-white outline-none focus:border-blue-400 transition"
                                            />
                                        </div>
                                    );
                                }

                                return (
                                    <div key={propKey} className="mb-4">
                                        <label className="block text-xs font-bold text-gray-700 mb-1">{formatPropLabel(propKey)}</label>
                                        <div className="flex gap-2">
                                            <input
                                                type="text"
                                                value={propValue}
                                                placeholder={imageField ? 'Paste image URL' : ''}
                                                onChange={(e) => handlePropChange(propKey, e.target.value)}
                                                className="w-full min-w-0 p-2.5 border border-gray-200 rounded-lg text-sm bg-gray-50 outline-none focus:border-blue-400 focus:bg-white transition"
                                            />
                                            {imageField && (
                                                <button
                                                    type="button"
                                                    onClick={() => openImagePicker(propKey)}
                                                    className="flex h-[42px] w-[42px] flex-shrink-0 items-center justify-center rounded-lg border border-blue-100 bg-blue-50 text-blue-600 transition hover:bg-blue-100"
                                                    title="Open Media Library"
                                                >
                                                    <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                                                        <rect x="3" y="3" width="18" height="18" rx="2" />
                                                        <circle cx="8.5" cy="8.5" r="1.5" />
                                                        <path d="M21 15l-5-5L5 21" />
                                                    </svg>
                                                </button>
                                            )}
                                        </div>
                                        {imageField && propValue && (
                                            <div className="mt-2 flex h-16 items-center justify-center overflow-hidden rounded-lg border border-gray-200 bg-gray-50">
                                                <img src={propValue} alt="" className="max-h-full max-w-full object-contain" />
                                            </div>
                                        )}
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                ) : (
                    <div className="p-4 space-y-5 flex-1">
                        {/* PAGE MANAGER WITH RESTORED ICONS */}




                        <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-200">
                            <p className="text-[10px] font-bold text-gray-400 mb-3 tracking-widest uppercase">Page Manager</p>
                            <select value={currentPage} onChange={(e) => setCurrentPage(e.target.value)} className="w-full p-2.5 mb-3 border border-gray-200 rounded-lg text-sm bg-white outline-none focus:border-blue-400">
                                {pagesList.map(page => <option key={page} value={page}>{page === 'home' ? 'Home' : page}</option>)}
                            </select>

                            <div className="flex gap-2 mb-3">
                                {/* Home Button */}
                                <button onClick={() => setCurrentPage('home')} className="flex-1 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 flex justify-center items-center transition" title="Go Home">
                                    <svg className="w-4 h-4 text-gray-500" fill="currentColor" viewBox="0 0 20 20"><path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" /></svg>
                                </button>
                                {/* Rename Button */}
                                <button onClick={handleRenamePage} className="flex-1 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 flex justify-center items-center transition" title="Rename Page">
                                    <svg className="w-4 h-4 text-gray-500" fill="currentColor" viewBox="0 0 20 20"><path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" /></svg>
                                </button>
                                {/* Delete Button */}
                                <button onClick={handleDeletePage} className="flex-1 py-2 border border-gray-200 rounded-lg hover:bg-red-50 hover:text-red-500 flex justify-center items-center transition" title="Delete Page">
                                    <svg className="w-4 h-4 text-gray-500 hover:text-red-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" /></svg>
                                </button>
                                {/* Live Button */}
                                <button onClick={openLivePage} className="flex-[2] px-2 py-2 border border-blue-100 text-blue-600 bg-blue-50 rounded-lg hover:bg-blue-100 font-bold text-sm flex justify-center items-center gap-1 transition">
                                    Live ↗
                                </button>
                            </div>

                            <div className="flex gap-2">
                                <input type="text" value={newPageName} onChange={(e) => setNewPageName(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleCreatePage()} placeholder="New Page Name" className="flex-1 w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-blue-400" />
                                <button onClick={handleCreatePage} className="bg-[#111827] text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-gray-800 transition">Create</button>
                            </div>
                        </div>

                        {/* FILE EXPLORER CARD */}
                        <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-200 mb-4">
                            <p className="text-[10px] font-bold text-gray-400 mb-3 tracking-widest uppercase">File Explorer</p>
                            <div className="flex items-center justify-between bg-[#f8f9fa] p-3 rounded-lg border border-gray-200">
                                <div className="flex items-center gap-3">
                                    <svg className="w-6 h-6" viewBox="0 0 88 88" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0 12.4L35.7 7.3V41.7H0V12.4ZM39.6 6.7L88 0V41.7H39.6V6.7ZM0 45.4H35.7V79.9L0 74.8V45.4ZM39.6 45.4H88V88L39.6 81.3V45.4Z" fill="#00a4ef" /></svg>
                                    <div>
                                        <p className="text-[13px] font-bold text-gray-800">Media Library</p>
                                        <p className="text-[11px] text-gray-400">Upload & Manage</p>
                                    </div>
                                </div>
                                <button onClick={() => openImagePicker()} className="bg-[#2d5bff] text-white px-4 py-1.5 rounded-lg text-[13px] font-bold hover:bg-blue-700 transition">Open</button>
                            </div>
                        </div>







                        {/* RESPONSIVE PREVIEW */}
                        <div className="p-4 bg-white border-t border-gray-200 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)] sticky bottom-0 mt-auto z-10">
                            <div className="flex items-center gap-2 mb-1">
                                <span className="bg-blue-50 text-blue-600 p-1.5 rounded-md text-xs">✏️</span>
                                <span className="font-bold text-[13px] text-gray-800">Live Page Builder</span>
                            </div>
                            <p className="text-[10px] text-gray-400 mb-3 ml-8">Drag elements into the preview screen</p>

                            <div className="flex bg-gray-50 p-1 rounded-lg border border-gray-200 mb-3">
                                <button onClick={() => setPreviewMode('desktop')} className={`flex-1 py-1.5 rounded-md flex justify-center transition ${previewMode === 'desktop' ? 'bg-white shadow-sm border border-gray-200 text-blue-600' : 'text-gray-400 hover:text-gray-600'}`}>
                                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><path d="M8 21h8m-4-4v4"></path></svg>
                                </button>
                                <button onClick={() => setPreviewMode('tablet')} className={`flex-1 py-1.5 rounded-md flex justify-center transition ${previewMode === 'tablet' ? 'bg-white shadow-sm border border-gray-200 text-blue-600' : 'text-gray-400 hover:text-gray-600'}`}>
                                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2"><rect x="4" y="2" width="16" height="20" rx="2" ry="2"></rect><path d="M12 18h.01"></path></svg>
                                </button>
                                <button onClick={() => setPreviewMode('mobile')} className={`flex-1 py-1.5 rounded-md flex justify-center transition ${previewMode === 'mobile' ? 'bg-white shadow-sm border border-gray-200 text-blue-600' : 'text-gray-400 hover:text-gray-600'}`}>
                                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect><path d="M12 18h.01"></path></svg>
                                </button>
                            </div>
                        </div>















                        {/* PRE-BUILT SECTIONS GRID */}

                        <div className="bg-white pb-4">
                            <p className="text-[13px] font-bold text-[#2d5bff] mb-4">Pre-built Sections</p>

                            <div className="grid grid-cols-2 gap-2">








                                {/* NEW REMOTE RECRUIT BUTTONS */}
                                <button onClick={() => addBlock('RemoteNavBlock')} className="flex flex-col items-center justify-center p-3 border border-gray-200 rounded-xl hover:border-[#2d5bff] hover:shadow-sm transition bg-[#e0ecff] group">
                                    <span className="text-xl mb-1 group-hover:scale-110 transition">🌐</span>
                                    <span className="text-[11px] font-bold text-[#1e3e85] mt-1 transition">Remote Nav</span>
                                </button>

                                <button onClick={() => addBlock('RemoteHeroBlock')} className="flex flex-col items-center justify-center p-3 border border-gray-200 rounded-xl hover:border-[#2d5bff] hover:shadow-sm transition bg-[#e0ecff] group">
                                    <span className="text-xl mb-1 group-hover:scale-110 transition">🌊</span>
                                    <span className="text-[11px] font-bold text-[#1e3e85] mt-1 transition">Remote Hero</span>
                                </button>

                                <button onClick={() => addBlock('RemoteFeatureBlock')} className="flex flex-col items-center justify-center p-3 border border-gray-200 rounded-xl hover:border-[#2d5bff] hover:shadow-sm transition bg-[#e0ecff] group">
                                    <span className="text-xl mb-1 group-hover:scale-110 transition">✨</span>
                                    <span className="text-[11px] font-bold text-[#1e3e85] mt-1 transition">Remote Feature</span>
                                </button>


                                <button onClick={() => addBlock('RemoteFeatureReverseBlock')} className="flex flex-col items-center justify-center p-3 border border-gray-200 rounded-xl hover:border-[#2d5bff] hover:shadow-sm transition bg-[#e0ecff] group">
                                    <span className="text-xl mb-1 group-hover:scale-110 transition">🔄</span>
                                    <span className="text-[11px] font-bold text-[#1e3e85] mt-1 transition">Feature Reverse</span>
                                </button>






                                <button onClick={() => addBlock('RemoteCtaBlock')} className="flex flex-col items-center justify-center p-3 border border-gray-200 rounded-xl hover:border-[#2d5bff] hover:shadow-sm transition bg-[#e0ecff] group">
                                    <span className="text-xl mb-1 group-hover:scale-110 transition">🎯</span>
                                    <span className="text-[11px] font-bold text-[#1e3e85] mt-1 transition">CTA Section</span>
                                </button>

                                <button onClick={() => addBlock('RemoteFaqBlock')} className="flex flex-col items-center justify-center p-3 border border-gray-200 rounded-xl hover:border-[#2d5bff] hover:shadow-sm transition bg-[#e0ecff] group">
                                    <span className="text-xl mb-1 group-hover:scale-110 transition">❓</span>
                                    <span className="text-[11px] font-bold text-[#1e3e85] mt-1 transition">FAQ Block</span>
                                </button>




                                <button onClick={() => addBlock('RemotePricingBlock')} className="flex flex-col items-center justify-center p-3 border border-gray-200 rounded-xl hover:border-[#2d5bff] hover:shadow-sm transition bg-[#e0ecff] group">
                                    <span className="text-xl mb-1 group-hover:scale-110 transition">💳</span>
                                    <span className="text-[11px] font-bold text-[#1e3e85] mt-1 transition">Pricing Table</span>
                                </button>

                                <button onClick={() => addBlock('RemoteFooterBlock')} className="flex flex-col items-center justify-center p-3 border border-gray-200 rounded-xl hover:border-[#2d5bff] hover:shadow-sm transition bg-[#e0ecff] group">
                                    <span className="text-xl mb-1 group-hover:scale-110 transition">🏁</span>
                                    <span className="text-[11px] font-bold text-[#1e3e85] mt-1 transition">Remote Footer</span>
                                </button>









                                <button onClick={() => addBlock('NavbarBlock')} className="flex flex-col items-center justify-center p-3 border border-gray-200 rounded-xl hover:border-[#2d5bff] hover:shadow-sm transition bg-[#f8f9fa] group">
                                    <svg className="w-6 h-6 text-gray-400 group-hover:text-[#2d5bff] transition" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2L4.5 20.29l.71.71L12 18l6.79 3 .71-.71L12 2z" /></svg>
                                    <span className="text-[11px] font-semibold text-gray-600 mt-2 group-hover:text-[#2d5bff] transition">Navigation</span>
                                </button>

                                <button onClick={() => addBlock('DropdownNavBlock')} className="flex flex-col items-center justify-center p-3 border border-gray-200 rounded-xl hover:border-[#2d5bff] hover:shadow-sm transition bg-[#f8f9fa] group">
                                    <svg className="w-6 h-6 text-gray-400 group-hover:text-[#2d5bff] transition" fill="currentColor" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5H7z" /></svg>
                                    <span className="text-[11px] font-semibold text-gray-600 mt-2 group-hover:text-[#2d5bff] transition">Dropdown Nav</span>
                                </button>

                                <button onClick={() => addBlock('PremiumMenuBlock')} className="flex flex-col items-center justify-center p-3 border border-gray-200 rounded-xl hover:border-[#2d5bff] hover:shadow-sm transition bg-[#f8f9fa] group">
                                    <svg className="w-6 h-6 text-gray-400 group-hover:text-[#2d5bff] transition" fill="currentColor" viewBox="0 0 24 24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z" /></svg>
                                    <span className="text-[11px] font-semibold text-gray-600 mt-2 group-hover:text-[#2d5bff] transition">Premium Menu</span>
                                </button>

                                <button onClick={() => addBlock('HeroBlock')} className="flex flex-col items-center justify-center p-3 border border-gray-200 rounded-xl hover:border-[#2d5bff] hover:shadow-sm transition bg-[#f8f9fa] group">
                                    <svg className="w-6 h-6 text-gray-400 group-hover:text-[#2d5bff] transition" fill="currentColor" viewBox="0 0 24 24"><path d="M11.99 18.54l-7.37-5.73L3 14.07l9 7 9-7-1.63-1.27-7.38 5.74zM12 16l7.36-5.73L21 9l-9-7-9 7 1.63 1.27L12 16z" /></svg>
                                    <span className="text-[11px] font-semibold text-gray-600 mt-2 group-hover:text-[#2d5bff] transition">Hero Block</span>
                                </button>

                                <button onClick={() => addBlock('TopBarBlock')} className="flex flex-col items-center justify-center p-3 border border-gray-200 rounded-xl hover:border-[#2d5bff] hover:shadow-sm transition bg-[#f8f9fa] group">
                                    <svg className="w-6 h-6 text-gray-400 group-hover:text-[#2d5bff] transition" fill="currentColor" viewBox="0 0 24 24"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z" /></svg>
                                    <span className="text-[11px] font-semibold text-gray-600 mt-2 group-hover:text-[#2d5bff] transition">Top Bar</span>
                                </button>

                                <button onClick={() => addBlock('FeaturesGridBlock')} className="flex flex-col items-center justify-center p-3 border border-gray-200 rounded-xl hover:border-[#2d5bff] hover:shadow-sm transition bg-[#f8f9fa] group">
                                    <svg className="w-6 h-6 text-gray-400 group-hover:text-[#2d5bff] transition" fill="currentColor" viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z" /></svg>
                                    <span className="text-[11px] font-semibold text-gray-600 mt-2 group-hover:text-[#2d5bff] transition">Features Grid</span>
                                </button>

                                <button onClick={() => addBlock('HeroSearchBlock')} className="flex flex-col items-center justify-center p-3 border border-gray-200 rounded-xl hover:border-[#2d5bff] hover:shadow-sm transition bg-[#f8f9fa] group">
                                    <svg className="w-6 h-6 text-gray-400 group-hover:text-[#2d5bff] transition" fill="currentColor" viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" /></svg>
                                    <span className="text-[11px] font-semibold text-gray-600 mt-2 group-hover:text-[#2d5bff] transition">Hero + Search</span>
                                </button>

                                <button onClick={() => addBlock('GlassSearchBlock')} className="flex flex-col items-center justify-center p-3 border border-gray-200 rounded-xl hover:border-[#2d5bff] hover:shadow-sm transition bg-[#f8f9fa] group">
                                    <svg className="w-6 h-6 text-gray-400 group-hover:text-[#2d5bff] transition" fill="currentColor" viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" /></svg>
                                    <span className="text-[11px] font-semibold text-gray-600 mt-2 group-hover:text-[#2d5bff] transition">Glass Search</span>
                                </button>

                                <button onClick={() => addBlock('FooterBlock')} className="flex flex-col items-center justify-center p-3 border border-gray-200 rounded-xl hover:border-[#2d5bff] hover:shadow-sm transition bg-[#f8f9fa] group">
                                    <svg className="w-6 h-6 text-gray-400 group-hover:text-[#2d5bff] transition" fill="currentColor" viewBox="0 0 24 24"><path d="M21 3H3v18h18V3zm-2 16H5v-4h14v4zm0-6H5V5h14v8z" /></svg>
                                    <span className="text-[11px] font-semibold text-gray-600 mt-2 group-hover:text-[#2d5bff] transition">Footer</span>
                                </button>

                                <button onClick={() => addBlock('SimpleFooterBlock')} className="flex flex-col items-center justify-center p-3 border border-gray-200 rounded-xl hover:border-[#2d5bff] hover:shadow-sm transition bg-[#f8f9fa] group">
                                    <svg className="w-6 h-6 text-gray-400 group-hover:text-[#2d5bff] transition" fill="currentColor" viewBox="0 0 24 24"><path d="M10.08 10.86c.05-.33.16-.62.3-.87s.34-.46.59-.62c.24-.15.54-.22.91-.23.23.01.44.05.63.13.2.09.38.21.52.36s.25.33.34.53.13.42.14.64h1.79c-.02-.47-.11-.9-.28-1.29s-.4-.73-.7-1.01-.66-.5-1.08-.66-.88-.23-1.39-.23c-.5 0-.96.08-1.38.24s-.78.38-1.1.66-.56.64-.75 1.06-.29.9-.29 1.45c0 .54.09.97.27 1.34s.43.68.74.92.68.43 1.11.56 1.01.2 1.48.2c.48 0 .91-.07 1.3-.21s.73-.35 1.02-.63.51-.62.68-1.01.25-.83.25-1.31h-1.8c-.02.26-.08.49-.19.68s-.25.35-.43.48-.38.21-.61.27-.47.08-.73.08c-.46 0-.85-.11-1.16-.32s-.48-.52-.63-.94c-.1-.23-.17-.51-.19-.83zm.74-4.83L9.4 4.6l-2.6 2.6 1.42 1.42 2.6-2.59zM19 19H5V5h4.13l1.87-1.87H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2v-4.13l-1.87 1.87V19z" /></svg>
                                    <span className="text-[11px] font-semibold text-gray-600 mt-2 group-hover:text-[#2d5bff] transition">Simple Footer</span>
                                </button>

                            </div>
                        </div>






                    </div>
                )}











                {/* SAVE BUTTON */}


                <div className="p-4 bg-white border-t border-gray-200 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)] sticky bottom-0 mt-auto z-10">


                    <button onClick={saveLayout} className="w-full bg-[#2d5bff] text-white py-2.5 rounded-lg shadow-sm hover:bg-blue-700 font-bold text-[13px] transition flex justify-center items-center gap-2">
                        <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M7.707 10.293a1 1 0 10-1.414 1.414l3 3a1 1 0 001.414 0l3-3a1 1 0 00-1.414-1.414L11 11.586V6h5a2 2 0 012 2v7a2 2 0 01-2 2H4a2 2 0 01-2-2V8a2 2 0 012-2h5v5.586l-1.293-1.293zM9 4a1 1 0 012 0v2H9V4z" /></svg>
                        {status || 'Save Layout'}
                    </button>
                </div>














            </div>

            {/* RIGHT CANVAS */}
            <div className="flex-1 p-8 overflow-y-auto relative">


                <div className={`mx-auto min-h-[600px] border-[2px] border-dashed border-gray-300 rounded-lg relative bg-white overflow-hidden shadow-sm transition-all duration-300 ease-in-out ${previewMode === 'mobile' ? 'w-[375px]' : previewMode === 'tablet' ? 'w-[768px]' : 'w-full max-w-[1100px]'}`}>






                    {layout.length === 0 && (
                        <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-400 font-medium">
                            <span className="text-4xl mb-4">📥</span>
                            <p>Page: <span className="font-bold text-gray-600">{currentPage}</span> is empty.</p>
                        </div>
                    )}
                    <div className="flex flex-col w-full h-full">
                        {layout.map((block, index) => {
                            const Component = BlockRegistry[block.type];
                            return (
                                <div
                                    key={block.id}
                                    draggable
                                    onDragStart={() => (dragItem.current = index)}
                                    onDragEnter={() => (dragOverItem.current = index)}
                                    onDragEnd={handleSort}
                                    onDragOver={(e) => e.preventDefault()}
                                    onClick={() => setActiveBlockIndex(index)}
                                    className={`relative group w-full cursor-pointer outline outline-2 transition-all ${activeBlockIndex === index ? 'outline-[#2d5bff] z-10' : 'outline-transparent hover:outline-gray-300'} ${block.type === 'RemoteNavBlock' ? 'pb-[100px] -mb-[100px] z-50' : ''}`}
                                >
                                    <div className="absolute top-0 left-1/2 -translate-x-1/2 bg-[#2d5bff] text-white flex items-center opacity-0 group-hover:opacity-100 transition-opacity z-20 rounded-b-md shadow-md">
                                        <div className="px-3 py-1 text-[11px] font-bold border-r border-blue-400 flex items-center gap-1.5 uppercase cursor-move tracking-wider">
                                            ☷ Drag
                                        </div>
                                        <button onClick={(e) => { e.stopPropagation(); removeBlock(index); }} className="px-3 py-1 hover:bg-red-500 transition font-bold rounded-br-md text-xs">✕</button>
                                    </div>
                                    <div className="pointer-events-none w-full">
                                        {Component ? <Component {...block.props} /> : null}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>
            <ScrollToTop />
        </div>
    );
}
