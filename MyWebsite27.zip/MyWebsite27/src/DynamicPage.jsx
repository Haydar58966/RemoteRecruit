import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { BlockRegistry, BlockDefaults } from './components/Blocks';
import ScrollToTop from './components/ScrollToTop';

export default function DynamicPage() {
    const { slug } = useParams();
    const currentSlug = slug || 'home';
    const [layout, setLayout] = useState([]);

    useEffect(() => {
        fetch(`/api/GetPage.aspx?slug=${currentSlug}`)
            .then(res => res.json())
            .then(data => {
                if (Array.isArray(data)) setLayout(data);
                else setLayout([]);
            });
    }, [currentSlug]);

    return (
        <div className="min-h-screen bg-white font-sans">
            {layout.length === 0 ? (
                <div className="flex justify-center items-center h-screen">Loading or Page Not Found...</div>
            ) : (
                layout.map((block, index) => {
                    // Backward compatibility check
                    const blockType = typeof block === 'string' ? block : block.type;
                    const props = typeof block === 'string' ? {} : { ...BlockDefaults[blockType], ...block.props };

                    const Component = BlockRegistry[blockType];
                    // Pass the props (brandName, btnText) into the live component!
                    return Component ? <Component key={index} {...props} /> : null;
                })
            )}
            <ScrollToTop />
        </div>
    );
}
