// ---  BLOCKS ---
export const NavbarBlock = ({ brandName, btnText }) => (
    <div className="w-full bg-[#2a3f6d] px-8 py-5 flex justify-between items-center text-white">
        <h1 className="text-xl font-bold tracking-wide">{brandName}</h1>
        <div className="flex gap-8 items-center text-sm font-medium">
            <span className="cursor-pointer hover:text-gray-200">Home</span>
            <span className="cursor-pointer hover:text-gray-200">About Us</span>
            <button className="bg-[#ef3f42] px-6 py-2.5 rounded font-bold shadow-sm">{btnText}</button>
        </div>
    </div>
);

export const HeroBlock = ({ brandName, btnText }) => (
    <div className="w-full bg-white border-b px-8 py-5 flex justify-between items-center text-black">
        <h1 className="text-xl font-bold tracking-wide">{brandName}</h1>
        <div className="flex gap-8 items-center text-sm font-medium text-gray-600">
            <span className="cursor-pointer hover:text-black">Home</span>
            <span className="cursor-pointer hover:text-black">Properties</span>
            <button className="bg-[#2d5bff] text-white px-6 py-2.5 rounded font-bold shadow-sm">{btnText}</button>
        </div>
    </div>
);

export const DropdownNavBlock = ({ brandName, link1, link2 }) => (
    <div className="w-full bg-gray-900 px-8 py-5 flex justify-between items-center text-white">
        <h1 className="text-xl font-bold">{brandName}</h1>
        <div className="flex gap-6 text-sm">
            <span className="cursor-pointer">{link1} ▾</span>
            <span className="cursor-pointer">{link2} ▾</span>
        </div>
    </div>
);

export const PremiumMenuBlock = ({ brandName, subtitle }) => (
    <div className="w-full bg-white border-b py-6 flex flex-col items-center text-center">
        <h1 className="text-3xl font-bold text-gray-800 uppercase tracking-widest">{brandName}</h1>
        <p className="text-xs text-gray-500 tracking-[0.2em] mt-1">{subtitle}</p>
        <div className="flex gap-8 mt-6 text-sm font-semibold text-gray-600">
            <span className="cursor-pointer hover:text-black">Home</span>
            <span className="cursor-pointer hover:text-black">Collections</span>
            <span className="cursor-pointer hover:text-black">Contact</span>
        </div>
    </div>
);

export const TopBarBlock = ({ message, phone }) => (
    <div className="w-full bg-gray-100 border-b text-gray-600 text-xs py-2 px-8 flex justify-between items-center font-medium">
        <span>{message}</span>
        <span>📞 {phone}</span>
    </div>
);

export const FeaturesGridBlock = ({ title, feature1, feature2, feature3 }) => (
    <div className="w-full py-16 px-8 bg-gray-50 text-center">
        <h2 className="text-3xl font-bold text-gray-800 mb-10">{title}</h2>
        <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 hover:-translate-y-1 transition duration-300">
                <div className="text-blue-500 text-4xl mb-4">🚀</div>
                <h3 className="font-bold text-lg mb-2">{feature1}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">Top tier performance to keep your users engaged.</p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 hover:-translate-y-1 transition duration-300">
                <div className="text-blue-500 text-4xl mb-4">🛡️</div>
                <h3 className="font-bold text-lg mb-2">{feature2}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">Enterprise-grade security protecting your data.</p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 hover:-translate-y-1 transition duration-300">
                <div className="text-blue-500 text-4xl mb-4">⚡</div>
                <h3 className="font-bold text-lg mb-2">{feature3}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">We guarantee 99.9% uptime for your business.</p>
            </div>
        </div>
    </div>
);

export const HeroSearchBlock = ({ headline, subhead, btnText }) => (
    <div className="w-full bg-[#2a3f6d] py-24 px-8 text-center text-white">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">{headline}</h1>
        <p className="text-lg text-blue-200 mb-8 max-w-2xl mx-auto">{subhead}</p>
        <div className="max-w-3xl mx-auto flex gap-2">
            <input type="text" placeholder="Search..." className="flex-1 p-4 rounded-lg text-black outline-none shadow-inner" />
            <button className="bg-[#ef3f42] px-8 py-4 rounded-lg font-bold hover:bg-red-600 transition shadow-lg">{btnText}</button>
        </div>
    </div>
);

export const GlassSearchBlock = ({ headline, subhead, btnText }) => (
    <div className="w-full py-24 px-8 text-center bg-gradient-to-br from-blue-400 to-indigo-600">
        <div className="max-w-3xl mx-auto bg-white/20 backdrop-blur-md border border-white/30 p-10 rounded-2xl shadow-2xl">
            <h1 className="text-4xl font-bold mb-2 text-white">{headline}</h1>
            <p className="text-blue-50 mb-8">{subhead}</p>
            <div className="flex gap-2">
                <input type="text" placeholder="What are you looking for?" className="flex-1 p-4 rounded-lg outline-none bg-white/90" />
                <button className="bg-[#111827] text-white px-8 py-4 rounded-lg font-bold hover:bg-gray-800 transition">{btnText}</button>
            </div>
        </div>
    </div>
);

export const FooterBlock = ({ brandName, description, email }) => (
    <div className="w-full bg-[#111827] text-white py-12 px-8">
        <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
                <h2 className="text-2xl font-bold mb-4">{brandName}</h2>
                <p className="text-gray-400 text-sm leading-relaxed">{description}</p>
            </div>
            <div>
                <h3 className="font-bold mb-4 text-gray-300">Quick Links</h3>
                <ul className="text-gray-400 text-sm space-y-2">
                    <li className="hover:text-white cursor-pointer transition">Home</li>
                    <li className="hover:text-white cursor-pointer transition">About Us</li>
                    <li className="hover:text-white cursor-pointer transition">Contact</li>
                </ul>
            </div>
            <div>
                <h3 className="font-bold mb-4 text-gray-300">Contact Us</h3>
                <p className="text-gray-400 text-sm">Email: {email}</p>
            </div>
        </div>
    </div>
);

export const SimpleFooterBlock = ({ text }) => (
    <div className="w-full bg-white border-t border-gray-200 py-6 text-center text-gray-500 text-sm font-medium">
        {text}
    </div>
);


// --- 🚀 NEW REMOTE RECRUIT BLOCKS 🚀 ---

export const RemoteNavBlock = ({ brandName, signInText, signUpText, logoUrl }) => {
    const cleanBrandName = (brandName || 'RemoteRecruit').replace(/\s+/g, '');
    const isRemoteRecruit = cleanBrandName.toLowerCase() === 'remoterecruit';
    const brandTop = isRemoteRecruit ? 'Remote' : brandName;
    const brandBottom = isRemoteRecruit ? 'Recruit' : '';

    return (
        <div className="relative z-20 h-0 w-full overflow-visible font-['Poppins']">
            <nav className="absolute left-0 top-0 z-20 flex w-full items-start justify-between px-6 pt-7 text-white md:px-[52px] md:pt-[31px]">
                <div className="flex min-h-[58px] cursor-pointer items-start">
                    {logoUrl ? (
                        <img
                            src={logoUrl}
                            alt={`${cleanBrandName} logo`}
                            className="h-auto w-[126px] max-w-full object-contain md:w-[139px]"
                        />
                    ) : (
                        <div className="relative flex flex-col items-start text-[29px] font-extrabold leading-[0.82] tracking-normal">
                            <span className="text-[#60b6d1]">{brandTop}</span>
                            {brandBottom ? (
                                <span className="relative text-white before:absolute before:left-[-9px] before:top-[15px] before:h-[6px] before:w-[6px] before:rounded-full before:bg-[#60b6d1]">
                                    {brandBottom}
                                </span>
                            ) : null}
                        </div>
                    )}
                </div>

                <div className="flex items-center gap-5 text-sm font-bold md:gap-[34px] md:text-[17px]">
                    <span className="cursor-pointer transition hover:text-white/80">{signInText}</span>
                    <button className="min-w-[95px] rounded-[22px] bg-[#60b6d1] px-[22px] py-3 text-center font-bold text-white shadow-[0_16px_30px_rgba(36,112,155,0.18)] transition hover:bg-[#52a8c3]">
                        {signUpText}
                    </button>
                </div>
            </nav>
        </div>
    );
};

export const RemoteHeroBlock = ({ title, subtitle }) => (
    <div className="relative flex min-h-[704px] w-full flex-col overflow-hidden bg-white px-6 pt-20 font-['Poppins']">
        <div className="absolute inset-0 z-0 h-full w-full overflow-hidden">
            <svg
                className="h-full w-full object-cover object-top"
                viewBox="0 0 1440 704"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                preserveAspectRatio="xMidYMid slice"
            >
                <path fillRule="evenodd" clipRule="evenodd" d="M1289.54 446.5C1324.03 446.5 1405.79 445.053 1439 446.5V0H0V700.621C42.0688 702.804 85.7979 704 131.121 704C651.054 704 840.511 446.5 1289.54 446.5Z" fill="url(#remoteHeroLowerCurve)" />
                <path d="M1440 0V652.537C1440 652.537 1262 519.631 1034 519.631C806 519.631 685.5 704 421.5 704C157.5 704 0 546.612 0 546.612V0H1440Z" fill="url(#remoteHeroMainCurve)" />
                <circle opacity="0.05" cx="894" cy="634" r="262" fill="white" />
                <circle opacity="0.02" cx="256" cy="-105" r="262" fill="white" />
                <defs>
                    <linearGradient id="remoteHeroLowerCurve" x1="-666.432" y1="437.828" x2="-52.7159" y2="1589.72" gradientUnits="userSpaceOnUse">
                        <stop stopColor="#52B4DA" />
                        <stop offset="1" stopColor="#1E3E85" />
                    </linearGradient>
                    <linearGradient id="remoteHeroMainCurve" x1="-644.712" y1="457.365" x2="-18.1383" y2="1596.48" gradientUnits="userSpaceOnUse">
                        <stop stopColor="#1E3E85" />
                        <stop offset="1" stopColor="#336DA6" />
                    </linearGradient>
                </defs>
            </svg>
        </div>

        <div className="relative z-10 mx-auto mt-20 max-w-[1040px] text-center text-white md:mt-28">
            <h2 className="mb-6 text-[40px] font-bold leading-[1.28] text-white md:text-[53px]">
                {title}
            </h2>
            <p className="mx-auto max-w-[800px] text-[16px] font-medium leading-[1.6] text-white opacity-80 md:text-[20px]">
                {subtitle}
            </p>
        </div>
    </div>
);

export const RemoteFeatureBlock = ({ badgeText, title, description, imageUrl }) => (
    <div className="w-full bg-white py-20 px-10">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center gap-16">

            {/* Left Text */}
            <div className="flex-1 text-left">
                <span className="inline-block bg-[#d2f3fd] text-[#336da6] px-5 py-2 rounded-full text-sm font-bold mb-6">
                    {badgeText}
                </span>
                <h2 className="text-4xl md:text-5xl font-bold text-[#111827] mb-6 leading-tight">
                    {title}
                </h2>
                <p className="text-gray-500 text-lg leading-relaxed">
                    {description}
                </p>
            </div>

            {/* Right Image */}
            <div className="flex-1 flex justify-center relative w-full">
                {imageUrl ? (
                    <img src={imageUrl} alt="Feature" className="max-w-full h-auto drop-shadow-2xl rounded-2xl" />
                ) : (
                    <div className="w-full aspect-square bg-gray-50 rounded-2xl flex flex-col items-center justify-center border-2 border-dashed border-gray-300 text-gray-400 p-8 text-center">
                        <span className="text-4xl mb-2">🖼️</span>
                        <p className="font-bold">Image Placeholder</p>
                        <p className="text-xs mt-2">Open your File Explorer, upload an image, and paste the URL into the Settings panel!</p>
                    </div>
                )}
            </div>

        </div>
    </div>
);








export const RemoteFeatureReverseBlock = ({ badgeText, title, description, imageUrl }) => (
    <div className="w-full bg-white py-20 px-10">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center gap-16">

            {/* Left Image */}
            <div className="flex-1 flex justify-center relative w-full">
                {imageUrl ? (
                    <img src={imageUrl} alt="Feature" className="max-w-full h-auto drop-shadow-2xl rounded-2xl" />
                ) : (
                    <div className="w-full aspect-square bg-gray-50 rounded-2xl flex flex-col items-center justify-center border-2 border-dashed border-gray-300 text-gray-400 p-8 text-center">
                        <span className="text-4xl mb-2">🖼️</span>
                        <p className="font-bold">Image Placeholder</p>
                        <p className="text-xs mt-2">Open your File Explorer, upload an image, and paste the URL into the Settings panel!</p>
                    </div>
                )}
            </div>

            {/* Right Text */}
            <div className="flex-1 text-left">
                <span className="inline-block bg-[#d2f3fd] text-[#336da6] px-5 py-2 rounded-full text-sm font-bold mb-6">
                    {badgeText}
                </span>
                <h2 className="text-4xl md:text-5xl font-bold text-[#111827] mb-6 leading-tight">
                    {title}
                </h2>
                <p className="text-gray-500 text-lg leading-relaxed">
                    {description}
                </p>
            </div>

        </div>
    </div>
);




















export const RemoteCtaBlock = ({ subtitle, title, description, btnText, imageUrl }) => (
    <div className="relative w-full bg-gradient-to-r from-[#edf2fa] to-[#edeaf6] py-24 px-8 overflow-hidden">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center gap-12">

            {/* Left Image (Mockup) */}
            <div className="flex-1 w-full flex justify-start relative z-10">
                {imageUrl ? (
                    <img src={imageUrl} alt="Dashboard" className="w-[120%] max-w-none -ml-8 md:-ml-20 drop-shadow-2xl rounded-l-none rounded-r-2xl" />
                ) : (
                    <div className="w-full aspect-video bg-white/60 rounded-r-2xl flex flex-col items-center justify-center border-2 border-dashed border-blue-300 text-blue-500 p-8 text-center backdrop-blur-sm -ml-8 md:-ml-20">
                        <span className="text-4xl mb-2">💻</span>
                        <p className="font-bold">Dashboard Image</p>
                    </div>
                )}
            </div>

            {/* Right Text */}
            <div className="flex-1 text-left z-10 md:pl-8">
                <p className="text-[#336da6] font-bold mb-3">{subtitle}</p>
                <h2 className="text-4xl md:text-5xl font-bold text-[#111827] mb-6 leading-tight">{title}</h2>
                <p className="text-gray-500 text-lg mb-8 max-w-md">{description}</p>
                <button className="bg-[#d2f3fd] text-[#204987] pr-6 pl-2 py-2 rounded-full font-bold hover:bg-[#b0e8fa] transition flex items-center gap-3">
                    <span className="bg-[#60b6d1] text-white rounded-full w-10 h-10 flex items-center justify-center text-xl">→</span>
                    {btnText}
                </button>
            </div>
        </div>

        {/* Decorative blur circles */}
        <div className="absolute top-10 left-40 w-20 h-20 bg-yellow-400 rounded-full blur-md opacity-80"></div>
        <div className="absolute bottom-16 right-1/4 w-10 h-10 bg-blue-600 rounded-full blur-[2px] opacity-80"></div>
    </div>
);




export const RemoteFaqBlock = ({ mainTitle, q1, a1, q2, a2, q3, a3, btnText }) => (
    <div className="w-full bg-white py-24 px-10">
        <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl font-bold text-[#111827] mb-12">{mainTitle}</h2>

            <div className="space-y-12">
                <div>
                    <h3 className="text-xl font-bold text-gray-800 mb-4">{q1}</h3>
                    <p className="text-gray-500 leading-relaxed">{a1}</p>
                </div>
                <div>
                    <h3 className="text-xl font-bold text-gray-800 mb-4">{q2}</h3>
                    <p className="text-gray-500 leading-relaxed">{a2}</p>
                </div>
                <div>
                    <h3 className="text-xl font-bold text-gray-800 mb-4">{q3}</h3>
                    <p className="text-gray-500 leading-relaxed">{a3}</p>
                </div>
            </div>

            <button className="mt-12 border-2 border-[#336da6] text-[#336da6] px-8 py-3 rounded-xl font-bold hover:bg-blue-50 transition">
                {btnText}
            </button>
        </div>
    </div>
);








export const RemotePricingBlock = ({ title, freeTitle, freeSubtitle, premiumPrice, premiumSubtitle, btnText }) => (
    <div className="relative w-full bg-white pt-24 pb-32 text-center z-0 overflow-hidden">
        <h2 className="text-4xl md:text-5xl font-bold text-[#111827] mb-16 relative z-10">{title}</h2>

        {/* Background Wave & Blue Bottom */}
        <div className="absolute bottom-0 left-0 w-full h-[55%] bg-[#204987] -z-10">
            <svg className="absolute bottom-full left-0 w-full h-[100px] md:h-[150px]" preserveAspectRatio="none" viewBox="0 0 1440 320" xmlns="http://www.w3.org/2000/svg">
                <path fill="#204987" d="M0,160L80,170.7C160,181,320,203,480,186.7C640,171,800,117,960,112C1120,107,1280,149,1360,170.7L1440,192L1440,320L1360,320C1280,320,1120,320,960,320C800,320,640,320,480,320C320,320,160,320,80,320L0,320Z"></path>
            </svg>
        </div>

        {/* Pricing Cards Container */}
        <div className="max-w-5xl mx-auto flex flex-col md:flex-row justify-center items-stretch gap-8 px-8 relative z-10">

            {/* Free Card */}
            <div className="flex-1 bg-white p-6 rounded-3xl shadow-xl flex flex-col justify-between border border-gray-100">
                <div className="flex flex-col md:flex-row gap-6 mb-8">
                    <div className="bg-[#f0f5ff] rounded-2xl p-6 flex flex-col justify-center items-center md:w-2/5">
                        <span className="text-[#60b6d1] text-3xl font-bold">{freeTitle}</span>
                        <span className="text-gray-400 font-medium mt-1">{freeSubtitle}</span>
                    </div>
                    <div className="flex-1 text-left flex flex-col justify-center gap-3">
                        <div className="flex items-center gap-3"><span className="text-[#336da6] bg-[#d2f3fd] rounded-full w-5 h-5 flex items-center justify-center text-xs">✓</span> <span className="text-sm text-gray-700 font-medium">1 Active Job</span></div>
                        <div className="flex items-center gap-3"><span className="text-[#336da6] bg-[#d2f3fd] rounded-full w-5 h-5 flex items-center justify-center text-xs">✓</span> <span className="text-sm text-gray-700 font-medium">Basic List Placement</span></div>
                        <div className="flex items-center gap-3"><span className="text-gray-400 bg-gray-100 rounded-full w-5 h-5 flex items-center justify-center text-xs">✕</span> <span className="text-sm text-gray-400 font-medium">Unlimited Job Applicants</span></div>
                        <div className="flex items-center gap-3"><span className="text-gray-400 bg-gray-100 rounded-full w-5 h-5 flex items-center justify-center text-xs">✕</span> <span className="text-sm text-gray-400 font-medium">Invite Anyone to Apply</span></div>
                    </div>
                </div>
                <button className="w-full border-2 border-[#204987] text-[#204987] font-bold py-4 rounded-xl hover:bg-blue-50 transition">{btnText}</button>
            </div>

            {/* Premium Card */}
            <div className="flex-1 bg-white p-6 rounded-3xl shadow-2xl flex flex-col justify-between border border-gray-100">
                <div className="flex flex-col md:flex-row gap-6 mb-8">
                    <div className="bg-[#f0f5ff] rounded-2xl p-6 flex flex-col justify-center items-center md:w-2/5 relative mt-4 md:mt-0">
                        <div className="absolute -top-4 bg-[#d2f3fd] text-[#204987] px-4 py-1.5 rounded-full text-xs font-bold flex items-center gap-1 shadow-sm">
                            🔥 Premium
                        </div>
                        <span className="text-[#336da6] text-3xl font-bold">{premiumPrice}</span>
                        <span className="text-gray-400 font-medium mt-1">{premiumSubtitle}</span>
                    </div>
                    <div className="flex-1 text-left flex flex-col justify-center gap-3">
                        <div className="flex items-center gap-3"><span className="text-[#336da6] bg-[#d2f3fd] rounded-full w-5 h-5 flex items-center justify-center text-xs">✓</span> <span className="text-sm text-gray-700 font-medium">Unlimited Job Posts</span></div>
                        <div className="flex items-center gap-3"><span className="text-[#336da6] bg-[#d2f3fd] rounded-full w-5 h-5 flex items-center justify-center text-xs">✓</span> <span className="text-sm text-gray-700 font-medium">Instant Job Post Approval</span></div>
                        <div className="flex items-center gap-3"><span className="text-[#336da6] bg-[#d2f3fd] rounded-full w-5 h-5 flex items-center justify-center text-xs">✓</span> <span className="text-sm text-gray-700 font-medium">Premium List Placement</span></div>
                        <div className="flex items-center gap-3"><span className="text-[#336da6] bg-[#d2f3fd] rounded-full w-5 h-5 flex items-center justify-center text-xs">✓</span> <span className="text-sm text-gray-700 font-medium">Unlimited Job Applicants</span></div>
                    </div>
                </div>
                <button className="w-full bg-[#204987] text-white font-bold py-4 rounded-xl shadow-lg hover:bg-blue-900 transition">{btnText}</button>
            </div>

        </div>
    </div>
);

export const RemoteFooterBlock = ({
    brandWord1,
    brandWord2,
    logoUrl,
    bottomLogoUrl,
    facebookIconUrl,
    instagramIconUrl,
    xIconUrl,
    twitterIconUrl,
    linkedinIconUrl,
    snapchatIconUrl
}) => {
    const mainLogoAlt = `${brandWord1 || 'Remote'} ${brandWord2 || 'Recruit'} logo`;

    const socialIcons = [
        {
            label: 'Facebook',
            iconUrl: facebookIconUrl,
            fallback: <span className="text-[22px] font-extrabold leading-none">f</span>
        },
        {
            label: 'Instagram',
            iconUrl: instagramIconUrl,
            fallback: (
                <svg className="h-[19px] w-[19px]" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                    <rect x="4" y="4" width="16" height="16" rx="5" stroke="currentColor" strokeWidth="2" />
                    <circle cx="12" cy="12" r="3.5" stroke="currentColor" strokeWidth="2" />
                    <circle cx="17" cy="7" r="1.2" fill="currentColor" />
                </svg>
            )
        },
        {
            label: 'X',
            iconUrl: xIconUrl,
            fallback: <span className="text-[18px] font-medium leading-none">X</span>
        },
        {
            label: 'Twitter',
            iconUrl: twitterIconUrl,
            fallback: (
                <svg className="h-[19px] w-[19px]" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M20.5 6.3c-.6.3-1.2.4-1.9.5.7-.4 1.1-1 1.4-1.8-.6.4-1.3.6-2 .8A3.2 3.2 0 0 0 12.5 8c0 .2 0 .5.1.7-2.7-.1-5.1-1.4-6.7-3.4-.3.5-.4 1-.4 1.6 0 1.1.6 2.1 1.4 2.7-.5 0-1-.2-1.5-.4v.1c0 1.6 1.1 2.9 2.6 3.2-.3.1-.6.1-.9.1-.2 0-.4 0-.6-.1.4 1.3 1.6 2.2 3 2.2A6.5 6.5 0 0 1 4.7 16c-.3 0-.6 0-.9-.1 1.4.9 3.1 1.4 4.9 1.4 5.8 0 9-4.8 9-9v-.4c.6-.4 1.1-1 1.5-1.6z" />
                </svg>
            )
        },
        {
            label: 'LinkedIn',
            iconUrl: linkedinIconUrl,
            fallback: <span className="text-[13px] font-extrabold leading-none">in</span>
        },
        {
            label: 'Snapchat',
            iconUrl: snapchatIconUrl,
            fallback: (
                <svg className="h-[19px] w-[19px]" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M12 3.8c-2.4 0-4.1 1.7-4.1 4.3v2c0 .4-.4.7-.9.8-.5.2-1 .4-1 .9 0 .4.4.7 1.1 1 .8.3 1.2.7 1.5 1.4.2.6.7.8 1.4.7.5-.1.9.1 1.2.5.2.3.5.5.8.5s.6-.2.8-.5c.3-.4.7-.6 1.2-.5.7.1 1.2-.1 1.4-.7.3-.7.7-1.1 1.5-1.4.7-.3 1.1-.6 1.1-1 0-.5-.5-.7-1-.9-.5-.1-.9-.4-.9-.8v-2c0-2.6-1.7-4.3-4.1-4.3z" />
                </svg>
            )
        }
    ];

    return (
        <footer className="relative w-full overflow-hidden bg-gradient-to-br from-[#3472a8] via-[#285d9f] to-[#234e91] px-8 pt-28 pb-0 font-['Poppins'] text-white md:px-10 md:pt-36">
            <div className="pointer-events-none absolute -bottom-44 left-36 h-[360px] w-[360px] rounded-full bg-white opacity-[0.035]"></div>
            <div className="pointer-events-none absolute -top-40 right-[-40px] h-[430px] w-[430px] rounded-full bg-white opacity-[0.045]"></div>

            <div className="relative z-10 mx-auto mb-24 flex max-w-[1476px] flex-col items-center justify-between gap-14 md:flex-row md:items-end">
                <div className="flex min-h-[118px] items-center">
                    {logoUrl ? (
                        <img
                            src={logoUrl}
                            alt={mainLogoAlt}
                            className="h-auto w-[240px] max-w-full object-contain md:w-[260px]"
                        />
                    ) : (
                        <div className="flex flex-col text-center text-[52px] font-extrabold leading-[0.82] tracking-normal md:text-left md:text-[58px]">
                            <span className="text-[#60b6d1]">{brandWord1}</span>
                            <span className="relative text-white before:absolute before:left-[-14px] before:top-[30px] before:h-[9px] before:w-[9px] before:rounded-full before:bg-[#60b6d1]">
                                {brandWord2}
                            </span>
                        </div>
                    )}
                </div>

                <div className="flex flex-wrap items-center justify-center gap-3 pb-10 md:justify-end md:gap-4">
                    {socialIcons.map(({ label, iconUrl, fallback }) => (
                        <div
                            key={label}
                            className="flex h-10 w-10 cursor-pointer items-center justify-center rounded-full bg-white/10 text-white/90 shadow-[inset_0_1px_0_rgba(255,255,255,0.12)] transition hover:bg-white/20"
                            aria-label={label}
                            title={label}
                        >
                            {iconUrl ? (
                                <img src={iconUrl} alt={`${label} icon`} className="h-[19px] w-[19px] object-contain" />
                            ) : fallback}
                        </div>
                    ))}
                </div>
            </div>

            <div className="relative z-10 border-t border-white/20 py-8 text-center">
                {bottomLogoUrl ? (
                    <img src={bottomLogoUrl} alt="Bottom logo" className="mx-auto h-auto w-[62px] object-contain" />
                ) : (
                    <span className="inline-flex items-center text-[42px] font-extrabold leading-none tracking-normal">
                        <span className="text-white">R</span>
                        <span className="-ml-2 text-[#60b6d1]">R</span>
                    </span>
                )}
            </div>
        </footer>
    );
};


















// --- REGISTRY AND DEFAULTS ---
export const BlockRegistry = {
    NavbarBlock, HeroBlock, DropdownNavBlock, PremiumMenuBlock,
    TopBarBlock, FeaturesGridBlock, HeroSearchBlock, GlassSearchBlock,
    FooterBlock, SimpleFooterBlock,
    RemoteNavBlock, RemoteHeroBlock, RemoteFeatureBlock, // <--- Registered new blocks

    RemoteFeatureReverseBlock, // <--- ADDED HERE


    RemoteCtaBlock, RemoteFaqBlock, // <--- ADDED HERE


    RemotePricingBlock, RemoteFooterBlock // <--- ADDED HERE





};

export const BlockDefaults = {
    NavbarBlock: { brandName: 'MyBrand', btnText: 'Contact Us' },
    HeroBlock: { brandName: 'MyBrand', btnText: 'Contact' },
    DropdownNavBlock: { brandName: 'MyBrand', link1: 'Services', link2: 'Pricing' },
    PremiumMenuBlock: { brandName: 'LUXURY', subtitle: 'Exclusive Real Estate' },
    TopBarBlock: { message: '🎉 Special Offer: Get 20% off today!', phone: '1-800-555-0199' },
    FeaturesGridBlock: { title: 'Why Choose Us?', feature1: 'Lightning Fast', feature2: 'Highly Secure', feature3: '24/7 Support' },
    HeroSearchBlock: { headline: 'Find Your Dream Home', subhead: 'Search thousands of properties available for sale and rent.', btnText: 'Search' },
    GlassSearchBlock: { headline: 'Explore the World', subhead: 'Book your next adventure today.', btnText: 'Explore' },
    FooterBlock: { brandName: 'MyBrand', description: 'Building the future of the web, one block at a time.', email: 'hello@mybrand.com' },
    SimpleFooterBlock: { text: '© 2024 MyBrand. All rights reserved.' },

    // Defaults for new blocks
    RemoteNavBlock: { brandName: 'RemoteRecruit', signInText: 'Sign In', signUpText: 'Sign Up', logoUrl: "" },
    RemoteHeroBlock: { title: "RemoteRecruit's Difference", subtitle: "RemoteRecruit is connecting the world with an easy-to-use platform that lets full-time, part-time, and freelance workers showcase their talents to businesses that need them. With no paywalls, no fees, and no barriers, there's nothing but you, your talents, and the next step in your career." },
    RemoteFeatureBlock: { badgeText: "Global Reach", title: "The First Fully Global Job Board, Anywhere, Ever", description: "RemoteRecruit connects candidates with opportunities around the world. With today's remote-first workforce, you need to be able to find the best jobs and the best people for them, wherever they may be.", imageUrl: "" },





    // ADDED HERE: Default text for the new block!
    RemoteFeatureReverseBlock: { badgeText: "Actually Fee Free", title: "Fee-Free Forever", description: "We don't charge you fees and we don't put up paywalls. We're the bridge that connects job opportunities with the best candidates, with no middleman involved.", imageUrl: "" },




    // ADDED HERE: Default text for the new CTA and FAQ blocks
    RemoteCtaBlock: { subtitle: "Are you ready?", title: "Help is only a few clicks away!", description: "Click Below to get set up super quickly and find help now!", btnText: "Get Started", imageUrl: "" },
    RemoteFaqBlock: { mainTitle: "Common Questions", q1: "Do I have to sign a long-term contract?", a1: "Actually beard single-origin coffee, twee 90's PBR Echo Park sartorial try-hard freegan Portland ennui.", q2: "Can I pay for a whole year?", a2: "Actually beard single-origin coffee, twee 90's PBR Echo Park sartorial try-hard freegan Portland ennui.", q3: "What if I need help?", a3: "Actually beard single-origin coffee, twee 90's PBR Echo Park sartorial try-hard freegan Portland ennui.", btnText: "More Questions" },




    // ADDED HERE: Default text for Pricing and Footer
    RemotePricingBlock: { title: "Help Is One Click Away", freeTitle: "Free", freeSubtitle: "Basic", premiumPrice: "$79.99", premiumSubtitle: "Per Month", btnText: "Get Started" },
    RemoteFooterBlock: {
        brandWord1: "Remote",
        brandWord2: "Recruit",
        logoUrl: "",
        bottomLogoUrl: "",
        facebookIconUrl: "",
        instagramIconUrl: "",
        xIconUrl: "",
        twitterIconUrl: "",
        linkedinIconUrl: "",
        snapchatIconUrl: ""
    }






};
