import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

export default function LandingPage() {
    // 1. Set up a place to store our website text (State)
    const [pageContent, setPageContent] = useState({
        HeroTitle: 'Loading...',
        HeroSubtitle: 'Loading...'
    });

    // 2. Fetch the text from the Database via our C# API when the page loads
    useEffect(() => {
        fetch('/api/GetContent.aspx')
            .then((response) => response.json())
            .then((data) => {
                // If the database has data, update our website with it!
                if (data && !data.error) {
                    setPageContent(data);
                }
            })
            .catch((error) => console.error("Error fetching content:", error));
    }, []);

    // 3. Display the website
    return (
        <div className="min-h-screen bg-white font-sans">

            {/* Navigation Bar */}
            <nav className="absolute top-0 left-0 w-full z-50 flex justify-between items-center py-6 px-6 md:px-16">
                <div className="flex items-center cursor-pointer">
                    <h1 className="text-2xl font-bold text-white tracking-tight">
                        Remote<span className="text-[#60b6d1]">Recruit</span>
                    </h1>
                </div>
                <div className="flex items-center gap-6">
                    <a href="#signin" className="text-white font-medium hover:text-gray-200 transition-colors duration-200">Sign In</a>
                    <a href="#signup" className="bg-[#60b6d1] hover:bg-[#4ea2bc] text-white font-semibold py-2 px-6 rounded-full shadow-lg transition-all duration-200 transform hover:scale-105">Sign Up</a>
                </div>
            </nav>

            {/* Hero Section */}
            <div className="relative w-full min-h-[704px] flex flex-col pt-20 px-6 font-['Poppins'] bg-white">
                <div className="absolute inset-0 w-full h-full z-0 overflow-hidden">
                    <svg className="w-full h-full object-cover object-top" viewBox="0 0 1440 704" fill="none" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice">
                        <path fillRule="evenodd" clipRule="evenodd" d="M1289.54 446.5C1324.03 446.5 1405.79 445.053 1439 446.5V0H0V700.621C42.0688 702.804 85.7979 704 131.121 704C651.054 704 840.511 446.5 1289.54 446.5Z" fill="url(#paint0_linear_1_315)"></path>
                        <path d="M1440 0V652.537C1440 652.537 1262 519.631 1034 519.631C806 519.631 685.5 704 421.5 704C157.5 704 0 546.612 0 546.612V0H1440Z" fill="url(#paint1_linear_1_315)"></path>
                        <defs>
                            <linearGradient id="paint0_linear_1_315" x1="-666.432" y1="437.828" x2="-52.7159" y2="1589.72" gradientUnits="userSpaceOnUse">
                                <stop stopColor="#52B4DA"></stop>
                                <stop offset="1" stopColor="#1E3E85"></stop>
                            </linearGradient>
                            <linearGradient id="paint1_linear_1_315" x1="-644.712" y1="457.365" x2="-18.1383" y2="1596.48" gradientUnits="userSpaceOnUse">
                                <stop stopColor="#1E3E85"></stop>
                                <stop offset="1" stopColor="#336DA6"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                </div>

                {/* REPLACED HARDCODED TEXT WITH DATABASE TEXT HERE */}
                <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.2 }} className="relative z-10 text-center max-w-[1040px] mx-auto mt-20 md:mt-28">
                    <h2 className="text-[40px] md:text-[53px] font-bold text-white leading-[1.28] mb-6">
                        {pageContent.HeroTitle}
                    </h2>
                    <p className="text-[16px] md:text-[20px] font-medium text-white opacity-80 leading-[1.6] max-w-[800px] mx-auto">
                        {pageContent.HeroSubtitle}
                    </p>
                </motion.div>
            </div>

        </div>
    );
}